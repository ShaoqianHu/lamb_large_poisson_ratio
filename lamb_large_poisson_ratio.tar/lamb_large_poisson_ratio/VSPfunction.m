function [Vr,Vk]=VSPfunction(x,t,velocity)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%equation (72)-(77)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
s3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+s3^2);
theta=atan(R/s3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Ts=beta*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
root=roots([1,-(Ts^2+cos(theta)^2-k^(-2))/(Ts*cos(theta)),1-k^(-2)]); %equation (69)
xi1=root(1);
xi2=root(2); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(t>r/beta)
    [Vsp2,Vsp3,Vsp4,Vsp5,Vsp6,Vsp7]=deal(0);
elseif(t<r/alpha*sin(theta)+r*sqrt(beta^(-2)-alpha^(-2))*cos(theta))
    [Vsp2,Vsp3,Vsp4,Vsp5,Vsp6,Vsp7]=deal(0);
else     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    C1=sqrt(xi1/xi2);
    C2=sqrt((xi1-Ts*cos(theta))/(xi2-Ts*cos(theta)));
    tau=sqrt(1-C1^2/C2^2);
    [K,E]=ellipke(tau^2);
    M=1/sqrt((xi1-Ts*cos(theta))*xi2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ray=roots([-16*(k^(-2)-1),8*(4*k^(-2)-3),8*(1-2*k^(-2)),1]);
    a3=sqrt(-ray(3)); %a3 is the actual root of Rayleigh function Rp(10)
    p1=(xi1-i*a3)/(xi2-i*a3);
    gama1=-Ts*cos(theta)*(xi2-i*a3)^2/((sin(theta)^2+a3^2-Ts^2+2*a3*Ts*cos(theta)*i)*xi2);
    part1=p1/(sin(theta)^2+a3^2-Ts^2+2*a3*Ts*cos(theta)*i)*ellip3(gama1,tau,1);
    A1=norm(sin(theta)^2+a3^2-Ts^2+2*a3*Ts*cos(theta)*i);
    theta1=angle(sin(theta)^2+a3^2-Ts^2+2*a3*Ts*cos(theta)*i);
    part2=pi/(2*sqrt(a3^2+1-k^(-2))*sqrt(A1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Vsp2=M*((Ts*cos(theta)-xi2)*imag(part1)/a3+K/(a3^2+xi2^2))-part2*sin(theta1/2)/a3;   
    Vsp3=M*((Ts*cos(theta)-xi2)*real(part1)+xi2*K/(a3^2+xi2^2))+part2*cos(theta1/2);       
    Vsp4=M*K;                                                          
    Vsp5=M*(xi2*K+(Ts*cos(theta)-xi2)*ellip3(Ts*cos(theta)/xi2,tau,1))+pi/2; 
    Vsp6=M*(xi2*Ts*cos(theta)*K+xi2*(xi1-Ts*cos(theta))*E...             
    +(Ts*cos(theta)-xi2)*Ts*cos(theta)*ellip3(Ts*cos(theta)/xi2,tau,1))+Ts*cos(theta)*pi/2;
    Vsp7=M/2*xi2*(3*Ts^2*cos(theta)^2+2*xi1*xi2-(xi1+xi2)*Ts*cos(theta)-xi1*Ts*cos(theta))*K...
    +M/2*3*Ts*cos(theta)*xi2*(xi1-Ts*cos(theta))*E...
    +M/2*(Ts*cos(theta)-xi2)*(3*Ts^2*cos(theta)^2+2*xi1*xi2-Ts*cos(theta)*(xi1+xi2))*ellip3(Ts*cos(theta)/xi2,tau,1)...
    +pi/4*(3*Ts^2*cos(theta)^2-Ts^2-cos(theta)^2+2-k^(-2));           
end
Vr=[Vsp2,Vsp3];
Vk=[Vsp7,Vsp6,Vsp5,Vsp4];
