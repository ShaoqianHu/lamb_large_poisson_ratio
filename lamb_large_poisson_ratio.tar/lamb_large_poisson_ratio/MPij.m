function M=MPij(x,t,velocity,ori)
% equation (12)-(19��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=norm(x);
theta=atan(R/x3);
phi=atan(x2/x1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Tp=alpha*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
b0=[1,0];         %B
b1=[1,0,0];       %B^2
b2=[1,0,-1];      %B^2-1
b3=[1,0,k^2-1];   %B^2+k^2-1
b4=[2,0,k^2-2];   %2*B^2+k^2-2
b5=[cos(theta),-Tp];%cos(theta)*B-T
b6=[cos(theta)^2,-2*Tp*cos(theta),Tp^2];%cos(theta)^2*B^2-2*T*cos(theta)*B+T^2
b7=[1,-2*Tp*cos(theta),Tp^2-sin(theta)^2];%cos(theta)^2*B^2-2*T*cos(theta)*B+T^2-sin(theta)^2
b8=[1,0,0,0];  
I1=8/sin(theta)^2*conv(conv(b1,b2),conv(b3,b6));
I2=8/sin(theta)^2*conv(conv(b1,b2),conv(b3,b7));
switch ori
    case 11
M=I1*cos(phi)^2-I2*sin(phi)^2;
    case 22
M=I1*sin(phi)^2-I2*cos(phi)^2;
    case {12,21}
M=(I1+I2)*sin(phi)*cos(phi);
    case 13
M=8*cos(phi)/sin(theta)*conv(conv(b2,b3),conv(b5,b8));
    case 23
M=8*sin(phi)/sin(theta)*conv(conv(b2,b3),conv(b5,b8));
    case 31
M=cos(phi)/sin(theta)*conv(conv(b0,b5),conv(conv(b4,b4),b4));
    case 32
M=sin(phi)/sin(theta)*conv(conv(b0,b5),conv(conv(b4,b4),b4));
    case 33
M=conv(conv(b1,b4),conv(b4,b4));
end