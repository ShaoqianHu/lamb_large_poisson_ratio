function VS1=VS1_m(x,t,velocity,a,rr)
%equation (61)
%a: the zero of Rayleigh function Rs, not actual root
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Ts=beta*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% note in VS1.m, we use xi1 < xi2, to ensure xi2*(xi2-Ts*cos(theta))>0,
%      there is a negative  sign in "coef"
if(Ts>1)
%	 % ............................................
	 root=roots([1,-(Ts^2+cos(theta)^2-k^(-2))/(Ts*cos(theta)),1-k^(-2)]);  %equation (57)
	 if root(1)>root(2)
	    xi1=root(2);
            xi2=root(1);
	 else
	    xi2=root(2);
            xi1=root(1);
	 end

	 coef   =-1.0/sqrt(xi2*(xi2-Ts*cos(theta)));
	 C1=-(xi1-Ts*cos(theta))/(Ts*cos(theta)-xi2);
         C2=sqrt(-C1)*1i;
         Cs1=sqrt(-xi1/xi2);
         Cs2=sqrt(-C1);

         C3=-(xi1-a)/(xi2-a);
%
         coefII = 1.0/(xi2-a);
         coefIII= (xi1-xi2)/(xi2-a)^2;
         coefIV =-(xi1-xi2)/(xi2-a)^2*C3;

         int1II = 1i/Cs2*ellip1_matlab(Cs1/Cs2,1i*C1/Cs1);
         int2II = 1i/Cs1*ellip1_matlab(Cs2/Cs1,1);

	 int1III=0.5*F(C3^2, Cs1^2, Cs2^2, 0, 1)-0.5*F(C3^2, Cs1^2, Cs2^2, C1^2, 1);
	 int2III=0.5*F(C3^2, Cs1^2, Cs2^2, C2^2, 2)-0.5*F(C3^2, Cs1^2, Cs2^2, 0, 2);

         int1IV = -1i/C3^2/Cs2*ellip3(-Cs1^2/C3^2, Cs1/Cs2, 1i*C1/Cs1);
         int2IV = -1i/C3^2/Cs1*ellip3(-Cs2^2/C3^2, Cs2/Cs1, 1);

         int = coefII*(int1II + int2II) ...
	 + coefIII*(int1III + int2III) ...
         + coefIV *(int1IV  + int2IV);
%
         %% the pole contribution
         b=0.5*(Ts^2-1)*sin(theta)^2/(Ts*cos(theta)-xi2)^2+0.5;
         c=0.5*(xi1-xi2)/(Ts*cos(theta)-xi2);
         aa=(xi1-a)/(xi2-a); x=real(aa); y=imag(aa);
         if(x<0 && y>0 && ((x-1.0)/b+1)^2 + y^2/c^2 < 1.0)
             z2=2*pi*1i/sqrt((a^2-1+1/k^2)*(a^2-2*a*Ts*cos(theta)+Ts^2-sin(theta)^2));
	 else
             z2=0;
         end
         V1=imag(rr*(int*coef+z2));

	 if Ts*cos(theta)< sqrt(1-1/k^2)
            upper=sqrt(1-1/k^2);
	    lower=Ts*cos(theta);
         
	    C1=(lower-xi1)/(lower-xi2);
	    C2=(upper-xi1)/(upper-xi2);
         
	    int1II=+1i/Cs1*ellip1(Cs2/Cs1,-1i*C2/Cs2)...
                -1i/Cs1*ellip1(Cs2/Cs1,-1i*C1/Cs2);
	    int1III=0.5*F(C3^2, Cs1^2, Cs2^2, C2^2, 1)-0.5*F(C3^2, Cs1^2, Cs2^2, C1^2, 1);
	    int1IV =-1i/C3^2/Cs1*ellip3(-Cs2^2/C3^2, Cs2/Cs1, -1i*C2/Cs2)...
                +1i/C3^2/Cs1*ellip3(-Cs2^2/C3^2, Cs2/Cs1, -1i*C1/Cs2);
         
	    int = coefII*(int1II) ...
                 + coefIII*(int1III) ...
                 + coefIV *(int1IV );

	    V2=-imag(int*coef*rr); 
	 else
            V2=0;
         end

	 V1=V1+V2;
else
         V1=0;
end
VS1=V1;

