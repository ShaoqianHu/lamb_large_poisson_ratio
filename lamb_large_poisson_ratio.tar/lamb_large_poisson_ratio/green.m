function green=green(x,t,velocity,ori,mu)
%the complete Green function, equation (1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
r=norm(x);
green=(greenp(x,t,velocity,ori)+greens(x,t,velocity,ori)+greensp(x,t,velocity,ori))/(pi^2*mu*r);
