function [Ur,Uk]=UPfunction(x,t,velocity)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%equation (29)-(31)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1); 
beta=velocity(2);
k=alpha/beta;
Tp=alpha*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
root=roots([16*(k^2-1),8*(3*k^4-8*k^2+6),8*(k^6-6*k^4+10*k^2-6),(k^2-2)^4]);
a3=sqrt(-root(1));  %a3 is the actual root of Rayleigh function Rp(10)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Tp>1)
    A1=norm(i*Tp*cos(theta)+sqrt(Tp^2-1)*sin(theta)+a3);
    A2=norm(i*Tp*cos(theta)-sqrt(Tp^2-1)*sin(theta)+a3);
    al1=angle(i*Tp*cos(theta)+sqrt(Tp^2-1)*sin(theta)+a3);
    al2=angle(i*Tp*cos(theta)-sqrt(Tp^2-1)*sin(theta)+a3);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Up2=pi*cos((al1+al2)/2)/(2*sqrt(A1*A2)*a3);
    Up3=pi*sin((al1+al2)/2)/(2*sqrt(A1*A2));
    Up4=pi/2;
    Up5=pi/2*Tp*cos(theta);
    Up6=pi/2*Tp^2*cos(theta)^2-pi/4*(Tp^2-1)*sin(theta)^2;
else
    [Up2,Up3,Up4,Up5,Up6]=deal(0);
end
Ur=[Up2,Up3];
Uk=[Up6,Up5,Up4];