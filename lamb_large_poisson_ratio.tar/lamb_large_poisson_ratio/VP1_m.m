function V1=VP1_m(x,t,velocity,a,rr)
%equation (33)
%a: the zero of Rayleigh function Rp(10), not actual root
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=norm(x);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Tp=alpha*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Tp>1)
    root=roots([1,-(Tp^2+cos(theta)^2-k^2)/(Tp*cos(theta)),1-k^2]);  %equation (32)
    if(root(1)>0)
        xi1=root(1);
        xi2=root(2);
    else
        xi2=root(1);
        xi1=root(2);
    end

    coef   =1.0/sqrt(xi2*(xi2-Tp*cos(theta)));
    C1=-(xi1-Tp*cos(theta))/(Tp*cos(theta)-xi2);
    C2=sqrt(-C1)*1i;
    Cp1=sqrt(-xi1/xi2);
    Cp2=sqrt(-C1);
    C3=-(xi1-a)/(xi2-a);

    coefII = 1.0/(xi2-a);
    coefIII= (xi1-xi2)/(xi2-a)^2;
    coefIV =-(xi1-xi2)/(xi2-a)^2;

    int1II =-1i/Cp2*ellip1(Cp1/Cp2,1i*C1/Cp1);
    int2II = 1i/Cp1*ellip1(Cp2/Cp1,1);

    int1III=0;
    int2III=0.5*F(C3^2, Cp1^2, Cp2^2, C2^2, 2)-0.5*F(C3^2, Cp1^2, Cp2^2, C1^2, 2);

    int1IV = -1i/C3/Cp2*ellip3(-Cp1^2/C3^2, Cp1/Cp2, 1i*C1/Cp1);
    int2IV = -1i/C3/Cp1*ellip3(-Cp2^2/C3^2, Cp2/Cp1, 1);

    int = coefII*(int1II + int2II) ...
         + coefIII*(int1III + int2III) ...
	 + coefIV *(int1IV  + int2IV);

    % the pole contribution
    b=0.5*(Tp^2-1)*sin(theta)^2/(Tp*cos(theta)-xi2)^2+0.5;
    c=0.5*(xi1-xi2)/(Tp*cos(theta)-xi2);
    aa=(xi1-a)/(xi2-a); x=real(aa); y=imag(aa);
    if(x<0 && y>0 && ((x-1.0)/b+1)^2 + y^2/c^2 < 1.0)
        z2=2*pi*1i/sqrt((a^2-xi1*xi2)*(a^2-2*a*Tp*cos(theta)+Tp^2-sin(theta)^2));
    else
        z2=0;
    end
    V1=imag(rr*(int*coef-z2));
else
    V1=0;
end


