function a=ellip1(tau, x0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the first kind of standard incomplete elliptic integral
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y=@(x)1./(sqrt(1-x.^2).*sqrt(1-tau^2*x.^2));
a=integral(y,0,x0);

end
