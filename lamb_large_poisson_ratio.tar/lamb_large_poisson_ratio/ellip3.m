function a=ellip3(c,tau,x0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the third kind of standard elliptic integral
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y5=@(x)1./((1-c*x.^2).*sqrt(1-x.^2).*sqrt(1-tau^2*x.^2));
a=integral(y5,0,x0);

end
