function result=computeIII_4(a,A,B,x0,x1)
% note the integral inteval is -A to -B

%temp=sqrt((A-B)*(a+B)/(-A-a)/(-A+B));
temp=sqrt(A-B)*sqrt(a+B)/sqrt(-A-a)/sqrt(-A+B);
temp1=log(-1i*(temp))-log(1i*(temp));
result=-1i*(temp1)/sqrt((-A-a)*(a+B));

end
