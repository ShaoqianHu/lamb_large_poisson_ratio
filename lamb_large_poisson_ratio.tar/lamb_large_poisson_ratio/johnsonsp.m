function johnsonsp=johnsonsp(x,t,velocity,ori)
%The SP part of the Green function by Johnson(1974) equation (4)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=norm(x);  
theta=atan(R/x3);
phi=atan(x2/x1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
mu=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t1=r/alpha*sin(theta)+sqrt(1/beta^2-1/alpha^2)*r*cos(theta);
p1=sqrt(t^2/r^2-1/beta^2);
p2=sqrt((t/r-sqrt(1/beta^2-1/alpha^2)*cos(theta))^2/sin(theta)^2-1/alpha^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=@(x)x;
q=@(x)-t/r*sin(theta)+sqrt(-p1^2+p(x).^2)*cos(theta);
eta1=@(x)sqrt(-q(x).^2+1/alpha^2+p(x).^2);
eta2=@(x)t/r*cos(theta)+sqrt(-p1^2+p(x).^2)*sin(theta);
%eta2=@(x)sqrt(-q(x).^2+1/beta^2+p(x).^2);
gama=@(x)eta2(x).^2+p(x).^2-q(x).^2;
sigma=@(x)gama(x).^2+4*eta1(x).*eta2(x).*(q(x).^2-p(x).^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch ori
    case 11
    y=@(x)(gama(x).*eta2(x).^2-(q(x).^2*sin(phi)^2-p(x).^2*cos(phi)^2).*(gama(x)-4*eta1(x).*eta2(x)))./eta2(x);
    case {12,21}
    y=@(x)(q(x).^2+p(x).^2).*(gama(x)-4*eta1(x).*eta2(x)).*sin(phi)*cos(phi)./eta2(x);
    case 22
    y=@(x)(gama(x).*eta2(x).^2-(q(x).^2*cos(phi)^2-p(x).^2*sin(phi)^2).*(gama(x)-4*eta1(x).*eta2(x)))./eta2(x);
    case 13
    y=@(x)-q(x).*gama(x)*cos(phi);
    case 23
    y=@(x)-q(x).*gama(x)*sin(phi);
    case 31
    y=@(x)-2*q(x).*eta1(x).*eta2(x)*cos(phi);
    case 32
    y=@(x)-2*q(x).*eta1(x).*eta2(x)*sin(phi);
    case 33
    y=@(x)2*eta1(x).*(q(x).^2-p(x).^2); 
end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    y1=@(x)y(x).*eta2(x)./(sigma(x).*sqrt(p(x).^2-p1^2));
    if(sin(theta)<beta/alpha)
        johnsonsp=0;
    elseif(t>r/beta)
        johnsonsp=0;
    elseif(t<t1)
        johnsonsp=0;
    else
johnsonsp=-imag(integral(y1,0,p2));
    end
end