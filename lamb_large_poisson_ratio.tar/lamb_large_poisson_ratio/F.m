function result=F(a,A,B,x, index)

if index==1
   if abs(A+x)<1e-10
	result=0;
   else
   	result=2*(A+x)*hypergeom([1/2,1],3/2,(a+B)*(A+x)/(a+A)/(B+x))/(-a-A)/sqrt((B+x)*(A+x));
   end
else
   if abs(B+x)<1e-10
	result=0;
   else
        result=2*(B+x)*hypergeom([1/2,1],3/2,(a+A)*(B+x)/(a+B)/(A+x))/(-a-B)/sqrt((A+x)*(B+x));
   end
end

end
