function johnson=johnson(x,t,velocity,ori,mu)
%The complete Green function by Johnson(1974)  equation (1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
r=norm(x);
johnson=(johnsonp(x,t,velocity,ori)+johnsons1(x,t,velocity,ori)+johnsons2(x,t,velocity,ori)+johnsonsp(x,t,velocity,ori))/(pi^2*mu*r);
%johnson=(johnsonp(x,t,velocity,ori))/(pi^2*mu*r);
%johnson=(johnsons1(x,t,velocity,ori)+johnsons2(x,t,velocity,ori))/(pi^2*mu*r);
%johnson=(johnsonsp(x,t,velocity,ori))/(pi^2*mu*r);
