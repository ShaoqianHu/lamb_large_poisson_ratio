% the code is only valid for k>1.7636 or Vp/Vs ratio nu > 0.2631

x=[10,0,2];
vp=8;
k=3;
vs=vp/k;
velocity=[vp,vs];
ori=33;
rho=2;
mu=rho*vs^2;

dt=0.2;
t=dt:dt:6;
nt=length(t);
gfn=zeros(nt,1);
gfn1=zeros(nt,1);
for it=1:nt
     gfn(it)=green(x,t(it),velocity,ori,mu);
     gfn1(it)=johnson(x,t(it),velocity,ori,mu);
end

plot(t,gfn);
hold on;
plot(t,gfn1);

