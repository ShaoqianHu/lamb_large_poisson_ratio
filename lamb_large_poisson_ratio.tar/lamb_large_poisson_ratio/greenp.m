function greenp=greenp(x,t,velocity,ori)
%P part of Green function  (28)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k=velocity(1)/velocity(2);
b1=[1,0,0];       %B^2
b2=[1,0,-1];      %B^2-1
b3=[1,0,k^2-1];   %B^2+k^2-1
b4=[2,0,k^2-2];   %2*B^2+k^2-2
RP=conv(conv(b4,b4),conv(b4,b4))-16*conv(conv(b1,b2),conv(b2,b3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=MPij(x,t,velocity,ori);
[r1,p1,k1]=residue(M,RP);
u5=-2*imag(p1(1))*imag(r1(1));    %u5=-(r1(1)*p1(2)+r1(2)*p1(1));
u6=2*real(r1(1));
[Ur,Uk]=UPfunction(x,t,velocity);
nonellip=UP1_m(x,t,velocity,p1(3),r1(3))+UP1_m(x,t,velocity,p1(4),r1(4))...
+UP1_m(x,t,velocity,p1(5),r1(5))+UP1_m(x,t,velocity,p1(6),r1(6))+dot(k1,Uk)+u5*Ur(1)+u6*Ur(2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=NPij(x,t,velocity,ori);
[r2,p2,k2]=residue(N,RP);
v5=-2*imag(p2(1))*imag(r2(1));  %v5=-(r2(1)*p2(2)+r2(2)*p2(1));
v6=2*real(r2(1));   %v6=r2(1)+r2(2);
[Vr,Vk]=VPfunction(x,t,velocity);
ellip=VP1_m(x,t,velocity,p2(3),r2(3))+VP1_m(x,t,velocity,p2(4),r2(4))...
+VP1_m(x,t,velocity,p2(5),r2(5))+VP1_m(x,t,velocity,p2(6),r2(6))+dot(k2,Vk)+v5*Vr(1)+v6*Vr(2);
greenp=(nonellip+ellip);
