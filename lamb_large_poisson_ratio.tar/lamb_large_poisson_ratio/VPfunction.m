function [Vr,Vk]=VPfunction(x,t,velocity)
%equation (34)-(39)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Tp=alpha*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Tp>1)
    root=roots([1,-(Tp^2+cos(theta)^2-k^2)/(Tp*cos(theta)),1-k^2]); %equation (32)
    if(root(1)>0)
        xi1=root(1);
        xi2=root(2);
    else
        xi2=root(1);
        xi1=root(2);
    end
    C1=-xi1/xi2;
    C2=(xi1-Tp*cos(theta))/(Tp*cos(theta)-xi2);
    tau=sqrt(C2/C1);
    [K,E]=ellipke(tau^2);
    M=1/sqrt(xi1*(Tp*cos(theta)-xi2));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ray=roots([16*(k^2-1),8*(3*k^4-8*k^2+6),8*(k^6-6*k^4+10*k^2-6),(k^2-2)^4]);
    a3=sqrt(-ray(1)); %a3 is the actual root of Rayleigh function Rp(10)
    p=1/2*(xi1+xi2)*(a3^2+xi2^2)-2*xi2*(a3^2+xi1*xi2);
    q=-((a3^2+xi1*xi2)/(2*a3)*(a3^2-xi2^2)+xi2*(xi1-xi2)*a3);
    m1=p+i*q;
    n1=2*(a3^2+xi1*xi2)^2-(a3^2+xi1^2)*(a3^2+xi2^2)+2*i*a3*(a3^2+xi1*xi2)*(xi1-xi2);
    z2=m1/n1*ellip3(-C2*(a3^2+xi2^2)^2/n1,tau,1);
    V2=M/(a3^2+xi2^2)*(2*(xi1-xi2)*real(z2)+K);  
    V3=M/(a3^2+xi2^2)*(-2*a3*(xi1-xi2)*imag(z2)+xi2*K); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    V4=M*K;    
    V5=M*((xi1-xi2)*ellip3(-C2,tau,1)+xi2*K);
    V6=M*(Tp*cos(theta)*xi2*K+xi1*(Tp*cos(theta)-xi2)*(E-K)+Tp*cos(theta)*(xi1-xi2)*ellip3(-C2,tau,1)); 
    V7=M/2*xi2*(3*Tp^2*cos(theta)^2-Tp^2+2-k^2-cos(theta)^2-Tp*cos(theta)*xi1)*K...
     +M/2*3*Tp*cos(theta)*xi1*(Tp*cos(theta)-xi2)*(E-K)...               
     +M/2*(xi1-xi2)*(3*Tp^2*cos(theta)^2-Tp^2+2-k^2-cos(theta)^2)*ellip3(-(xi1-Tp*cos(theta))/(Tp*cos(theta)-xi2),tau,1);
else
    [V2,V3,V4,V5,V6,V7]=deal(0);
end
Vr=[V2,V3];
Vk=[V7,V6,V5,V4];
