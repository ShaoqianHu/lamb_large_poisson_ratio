function Up1=UP1_m(x,t,velocity,a, rr)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%equation (29)
%a: the zero of Rayleigh function Rp(10), not actual root
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
Tp=alpha*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Tp>1)
  C= Tp*cos(theta)-a+1i*sqrt(Tp^2-1)*sin(theta);
  D=-2i*sqrt(Tp^2-1)*sin(theta);
  Up1=pi/2*(1/C*sqrt(C/(C+D)));
  Up1=real(Up1*rr);
else
  Up1=0;
end
