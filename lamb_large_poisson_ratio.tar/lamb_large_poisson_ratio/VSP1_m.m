function Vsp1=VSP1_m(x,t,velocity,a,rr)
%equation (71)
%a: the zero of Rayleigh function Rs, not actual root
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Ts=beta*t/r;
tsp=r/alpha*sin(theta)+r*sqrt(1/beta^2-1/alpha^2)*cos(theta);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Ts<1 && t> tsp)
	%%
	lower=Ts*cos(theta)+sqrt(1-Ts^2)*sin(theta);
	upper=sqrt(1-1/k^2);

	root=roots([1,-(Ts^2+cos(theta)^2-k^(-2))/(Ts*cos(theta)),1-k^(-2)]);  %equation (57)
        xi1=root(1);
        xi2=root(2);

        coef   =1.0/sqrt(xi2*(xi2-Ts*cos(theta)));
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        C1=(lower-xi1)/(lower-xi2);%%
        C2=(upper-xi1)/(upper-xi2); %%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Cs1=sqrt(-xi1/xi2);
        Cs2=sqrt((xi1-Ts*cos(theta))/(Ts*cos(theta)-xi2));
        C3=-(xi1-a)/(xi2-a);

        coefII = 1.0/(xi2-a);
        coefIII= (xi1-xi2)/(xi2-a)^2;
        coefIV =-(xi1-xi2)/(xi2-a)^2;

	int1II =+1i/Cs1*ellip1(Cs2/Cs1,1i*C2/Cs2)...
	        -1i/Cs1*ellip1(Cs2/Cs1,1i*C1/Cs2);

	int1III= 0.5*computeIII(C3^2,Cs1^2,Cs2^2,C2^2);

	int1IV =-1i/C3/Cs1*ellip3(-Cs2^2/C3^2, Cs2/Cs1, 1i*C2/Cs2)...
	        +1i/C3/Cs1*ellip3(-Cs2^2/C3^2, Cs2/Cs1, 1i*C1/Cs2);

	int = coefII*(int1II) ...
         + coefIII*(int1III) ...
         + coefIV *(int1IV );

        Vsp1=-imag(int*coef*rr);
else
        Vsp1=0;
end
end
