function [Ur,Uk]=USfunction(x,t,velocity)
%the same as UPfunction except changing Tp to Ts  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Ts=beta*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
root=roots([-16*(k^(-2)-1),8*(4*k^(-2)-3),8*(1-2*k^(-2)),1]);
a3=sqrt(-root(3)); %a3 is the actual root of Rayleigh function Rs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Ts>1)
    A1=norm(i*Ts*cos(theta)+sqrt(Ts^2-1)*sin(theta)+a3);
    A2=norm(i*Ts*cos(theta)-sqrt(Ts^2-1)*sin(theta)+a3);
    al1=angle(i*Ts*cos(theta)+sqrt(Ts^2-1)*sin(theta)+a3);
    al2=angle(i*Ts*cos(theta)-sqrt(Ts^2-1)*sin(theta)+a3);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Us2=pi*cos((al1+al2)/2)/(2*sqrt(A1*A2)*a3);
    Us3=pi*sin((al1+al2)/2)/(2*sqrt(A1*A2));
    Us4=pi/2;
    Us5=pi/2*Ts*cos(theta);
    Us6=pi/2*Ts^2*cos(theta)^2-pi/4*(Ts^2-1)*sin(theta)^2;
else
    [Us2,Us3,Us4,Us5,Us6]=deal(0);
end
Ur=[Us2,Us3];
Uk=[Us6,Us5,Us4];