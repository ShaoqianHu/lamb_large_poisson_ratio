function Us1=US1_m(x,t,velocity,a, rr)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%equation (29)
%a: the zero of Rayleigh function Rp(10), not actual root
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
k=velocity(1)/velocity(2);
beta=velocity(2);
Ts=beta*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Ts>1)
  C= Ts*cos(theta)-a+1i*sqrt(Ts^2-1)*sin(theta);
  D=-2i*sqrt(Ts^2-1)*sin(theta);
  Us1=pi/2*(1/C*sqrt(C/(C+D)));
  Us1=Us1*1i;
  Us1=imag(rr*Us1);
else
  Us1=0;
end
