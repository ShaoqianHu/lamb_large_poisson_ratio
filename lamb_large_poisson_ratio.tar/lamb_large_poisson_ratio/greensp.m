function greensp=greensp(x,t,velocity,ori)
%S-P part of Green function  (70)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
theta=atan(R/x3);
k=velocity(1)/velocity(2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
b1=[1,0,0];       %B^2
b2=[1,0,-1];      %B^2-1
b3=[1,0,k^(-2)-1];   %B^2+k^(-2)-1
b4=[2,0,-1];   %2*B^2-1
RS=conv(conv(b4,b4),conv(b4,b4))-16*conv(conv(b1,b2),conv(b2,b3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(sin(theta)>1/k)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    N=NSij(x,t,velocity,ori);
    [r2,p2,k2]=residue(N,RS);
    v5=-2*imag(p2(5))*imag(r2(5));  %v5=-(r2(1)*p2(2)+r2(2)*p2(1));
    v6=2*real(r2(5));   %v6=r2(1)+r2(2);
    [Vr,Vk]=VSPfunction(x,t,velocity);
    ellips=VSP1_m(x,t,velocity,p2(1),r2(1))...
          +VSP1_m(x,t,velocity,p2(2),r2(2))...
          +VSP1_m(x,t,velocity,p2(3),r2(3))...
	  +VSP1_m(x,t,velocity,p2(4),r2(4))...
	  +v5*Vr(1)+v6*Vr(2)+dot(k2,Vk);

    greensp=ellips;
else
    greensp=0;
end
