function N=NSij(x,t,velocity,ori)
%equation��49��-��56��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=norm(x);
theta=atan(R/x3);
phi=atan(x2/x1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Ts=beta*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
b0=[1,0];         %B
b1=[1,0,0];       %B^2
b2=[1,0,-1];      %B^2-1
b3=[1,0,k^(-2)-1];   %B^2+k^(-2)-1
b4=[2,0,-1];   %2*B^2-1
b5=[cos(theta),-Ts];%cos(theta)*B-T
b6=[cos(theta)^2,-2*Ts*cos(theta),Ts^2];%cos(theta)^2*B^2-2*T*cos(theta)*B+T^2
b7=[1,-2*Ts*cos(theta),Ts^2-sin(theta)^2];%cos(theta)^2*B^2-2*T*cos(theta)*B+T^2-sin(theta)^2
b8=[1,0,0,0];      %B^3
I3=-4/sin(theta)^2*conv(conv(b3,b4),conv(b6,b8));
I4=4/sin(theta)^2*conv(conv(b3,b4),conv(b7,b8));
I5=-2/sin(theta)*conv(conv(b3,b4),conv(b1,b5));
switch ori
    case 11
N=I3*cos(phi)^2+I4*sin(phi)^2;
    case 22
N=I3*sin(phi)^2+I4*cos(phi)^2;
    case {12,21}
N=(I3-I4)*sin(phi)*cos(phi);
    case 13
N=2*cos(phi)*conv(I5,b2);
    case 23
N=2*sin(phi)*conv(I5,b2);
    case 31
N=cos(phi)*conv(I5,b4);
    case 32
N=sin(phi)*conv(I5,b4);
    case 33
N=-2*conv(conv(conv(b2,b3),conv(b4,b4)),b0);
end