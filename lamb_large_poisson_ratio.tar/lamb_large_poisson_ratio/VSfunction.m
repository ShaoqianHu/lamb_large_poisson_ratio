function [Vr,Vk]=VSfunction(x,t,velocity)
% equation (61)-(67)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% geometry
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+x3^2);
theta=atan(R/x3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%medium
alpha=velocity(1);
beta=velocity(2);
k=alpha/beta;
Ts=beta*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
root=roots([1,-(Ts^2+cos(theta)^2-k^(-2))/(Ts*cos(theta)),1-k^(-2)]); %equation (57)
xi1=root(1);
xi2=root(2); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(t<r/beta)
    [V2,V3,V4,V5,V6,V7]=deal(0);
else     
    ray=roots([-16*(k^(-2)-1),8*(4*k^(-2)-3),8*(1-2*k^(-2)),1]);
    a3=sqrt(-ray(3)); %a3 is the actual root of Rayleigh function Rp(10)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    C1=sqrt(xi1/xi2);
    C2=sqrt((xi1-Ts*cos(theta))/(Ts*cos(theta)-xi2));
    tau=sqrt(C2^2/(C1^2+C2^2));
    [K,E]=ellipke(tau^2);
    M=1/sqrt(Ts*cos(theta)*(xi1-xi2));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    p=1/2*(xi1+xi2)*(a3^2+xi2^2)-2*xi2*(a3^2+xi1*xi2);
    q=-((a3^2+xi1*xi2)/(2*a3)*(a3^2-xi2^2)+xi2*(xi1-xi2)*a3);
    m1=p+i*q;
    n1=C2^2*(a3^2+xi2^2)^2+2*(a3^2+xi1*xi2)^2-(a3^2+xi1^2)*(a3^2+xi2^2)+2*i*a3*(a3^2+xi1*xi2)*(xi1-xi2);
    z2=m1/n1*ellip3(C2^2*(a3^2+xi2^2)^2/n1,tau,1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    V2=M/(a3^2+xi2^2)*(2*(xi1-xi2)*real(z2)+K); 
    V3=M/(a3^2+xi2^2)*(-2*(xi1-xi2)*a3*imag(z2)+xi2*K);
    V4=M*K;
    V5=M*(xi2*K+(Ts*cos(theta)-xi2)*ellip3((xi1-Ts*cos(theta))/(xi1-xi2),tau,1));
    V6=M*(Ts*cos(theta)*(xi1-xi2)*E+(xi1*xi2-(xi1-xi2)*Ts*cos(theta))*K)...
    +M*(Ts*cos(theta)-xi2)*Ts*cos(theta)*ellip3((xi1-Ts*cos(theta))/(xi1-xi2),tau,1);
    V7=M/2*xi2*(3*Ts^2*cos(theta)^2-Ts^2+2-k^(-2)-cos(theta)^2-Ts*cos(theta)*xi1)*K...
      -M/2*3*Ts*cos(theta)*xi1*(Ts*cos(theta)-xi2)*K...
      +M/2*3*Ts^2*cos(theta)^2*(xi1-xi2)*E...
      +M/2*(Ts*cos(theta)-xi2)*(3*Ts^2*cos(theta)^2-Ts^2+2-k^(-2)-cos(theta)^2)*ellip3((xi1-Ts*cos(theta))/(xi1-xi2),tau,1);
end
Vr=[V2,V3];
Vk=[V7,V6,V5,V4];
