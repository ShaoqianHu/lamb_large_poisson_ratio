function greens=greens(x,t,velocity,ori)
%S part of Green function  (60)��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k=velocity(1)/velocity(2);
b1=[1,0,0];       %B^2
b2=[1,0,-1];      %B^2-1
b3=[1,0,k^(-2)-1];   %B^2+k^(-2)-1
b4=[2,0,-1];   %2*B^2-1
RS=conv(conv(b4,b4),conv(b4,b4))-16*conv(conv(b1,b2),conv(b2,b3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=MSij(x,t,velocity,ori);
[r1,p1,k1]=residue(M,RS);
u5=-2*imag(p1(5))*imag(r1(5));    %u5=-(r1(1)*p1(2)+r1(2)*p1(1));
u6=2*real(r1(5));
[Ur,Uk]=USfunction(x,t,velocity);
nonellips=US1_m(x,t,velocity,p1(3),r1(3))+US1_m(x,t,velocity,p1(4),r1(4))...
+US1_m(x,t,velocity,p1(1),r1(1))+US1_m(x,t,velocity,p1(2),r1(2))+u5*Ur(1)+u6*Ur(2)+dot(k1,Uk);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=NSij(x,t,velocity,ori);
[r2,p2,k2]=residue(N,RS);
v5=-2*imag(p2(5))*imag(r2(5));  %v5=-(r2(1)*p2(2)+r2(2)*p2(1));
v6=2*real(r2(5));   %v6=r2(1)+r2(2);
[Vr,Vk]=VSfunction(x,t,velocity);
ellips=VS1_m(x,t,velocity,p2(3),r2(3))+VS1_m(x,t,velocity,p2(4),r2(4))...
+VS1_m(x,t,velocity,p2(1),r2(1))+VS1_m(x,t,velocity,p2(2),r2(2))+v5*Vr(1)+v6*Vr(2)+dot(k2,Vk);
greens=nonellips+ellips;
