function a=ellip1_matlab(tau, x0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the first kind of standard incomplete elliptic integral
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m=tau^2;
phi=asin(x0);

a=ellipticF(phi, m);

end
