# Validation

This document records how the Python port was validated and the level of agreement that
can be expected. The headline result is that the **closed-form P part reproduces the
independent Johnson (1974) quadrature to near machine precision**, which is the strongest
available cross-check.

---

## 1. Validation strategy

The original MATLAB code is a closed-form implementation, so there is no "ground truth"
solution to compare against directly. Instead the port is validated three ways:

1. **Independent-method cross-check.** The package contains a second, entirely separate
   implementation of the same Green's function (the Johnson 1974 numerical integrals).
   Where the physics is shared, the two must agree.
2. **Identity checks.** Each special-function replacement (hypergeometric -> elementary,
   elliptic helpers, partial-fraction reconstruction) is checked against a reference
   evaluation.
3. **Regression table.** A full time series is compared between the two methods and
   archived as `results.csv` / `test_green.png` by `examples/test_green.py`.

## 2. P part: closed form vs Johnson — machine precision

The strongest check is `greenp` versus `johnsonp`. These are two independent code paths
(the closed form uses residue/elliptic machinery; Johnson uses adaptive quadrature over
the slowness integrand). They agree to ~1e-14–1e-15 absolute over the whole time range:

```
t=1.4   greenp=-8.053272936526e-03  johnsonp=-8.053272936537e-03  diff=1.0e-14
t=1.8   greenp=-4.757135902703e-02  johnsonp=-4.757135902705e-02  diff=1.1e-14
t=2.6   greenp=-8.831010176775e-02  johnsonp=-8.831010176776e-02  diff=8.2e-15
t=4.0   greenp=-6.462491550976e-01  johnsonp=-6.462491550976e-01  diff=4.8e-15
t=5.0   greenp=-1.531254179334e+00  johnsonp=-1.531254179334e+00  diff=2.0e-15
```

This is the regression invariant asserted in `tests/test_regression.py`.

## 3. Hypergeometric -> elementary identity

The closed form uses `2F1(1/2, 1; 3/2; z)`. The port replaces it with the elementary
identity `atanh(sqrt(z))/sqrt(z)`. Checked against `mpmath.hyp2f1` over a grid covering
negative reals, positive reals, large `|z|`, complex values, and both sides of the branch
cut `[1, inf)`:

```
max relative deviation vs mp.hyp2f1: 8.99e-22
timing: hyp2f1 0.476 ms/call  ->  elementary 0.130 ms/call   (~4x faster)
```

## 4. Full time series (closed form vs Johnson)

`examples/test_green.py` evaluates both methods for `x=[10,0,2]`, `vp=8`, `k=3`,
`ori=33`, `rho=2` over `t = 0.2..6.0`. Summary:

- **Before the P arrival** (`t < r/vp ~ 1.27`): both methods return exactly 0.
- **P arrival** (up to ~1.8): agreement to machine precision (see above).
- **S / SP window** (~2.0–4.0): max absolute difference ~6e-5, i.e. ~1% relative.
- **Late time** (> 4): converges; relative difference ~1%.

```
max |green - johnson| = 6.05e-05
```

## 5. Known deviations (properties of the original, not porting errors)

The ~1% disagreement in the S/SP mid-arrival window is **not** a porting error. Evidence:

- The P part, which exercises the same residue/elliptic machinery, agrees to ~1e-15.
- The Python code reproduces the MATLAB formulas literally (see
  `docs/MATLAB_MAPPING.md`); no approximation has been introduced in the S/SP path.
- The discrepancy is at the ~1% level and structurally consistent with the type-II
  closed form as published, rather than with a transcription mistake (which would
  typically produce order-of-magnitude or sign errors).

Other documented properties of the solution in this regime:

- The S arrival carries the logarithmic singularity typical of the type-II solution.
- Off-diagonal components are not symmetric (`G13 != G31`); the asymmetry is baked into
  the original MATLAB formulas of both the closed-form and Johnson paths and is
  reproduced here.

## 6. Relationship to the original MATLAB code

The port could not be executed against a live MATLAB session, so numeric
MATLAB-vs-Python comparison is not included. Fidelity is instead established by:

- literal file-by-file transcription of all 24 MATLAB sources,
- the independent-method cross-check above, and
- the identity checks in sections 3–4.

One behavioural difference is intentional and is an improvement: the MATLAB `greensp`
path errors at runtime because `computeIII.m` declares 5 inputs but is called with 4;
the Python `computeIII` makes the trailing arguments optional so the SP branch runs.
See `docs/MATLAB_MAPPING.md`.

## 7. Reproducing the validation

```bash
pip install pytest
pytest tests/ -v                  # fast identity + regression tests
python examples/test_green.py     # full table -> results.csv, test_green.png
```
