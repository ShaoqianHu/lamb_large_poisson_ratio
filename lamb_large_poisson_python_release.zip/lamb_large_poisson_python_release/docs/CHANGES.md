# Changes relative to the original MATLAB code

This package is a faithful port of the MATLAB package `lamb_large_poisson_ratio`:
**every physical formula is transcribed unchanged**. The items below are the only
differences, and each is either a numerical improvement with a proven identity, a fix
for a defect in the original, or a robustness substitution for an undocumented MATLAB
behaviour. Numerical results are unchanged except where noted.

---

## 1. Hypergeometric function replaced by an elementary identity

**Where:** `F.m` -> `lamb_large/elliptic.py` (`F`, helper `_hyp2f1_12132`).

The MATLAB code evaluates

```matlab
hypergeom([1/2, 1], 3/2, z)
```

which requires the Symbolic Math Toolbox and is slow. This port uses the exact
elementary identity

```
2F1(1/2, 1; 3/2; z) = atanh(sqrt(z)) / sqrt(z)
                    = log((1 + sqrt(z)) / (1 - sqrt(z))) / (2 sqrt(z)),
```

with a short power series (`1 + z/3 + z^2/5 + z^3/7`) for `|z| < 1e-6` to avoid
cancellation near zero.

- **Accuracy:** verified against `mpmath.hyp2f1` to better than 1e-21 relative over
  real, complex, large-magnitude arguments and on both sides of the branch cut
  `[1, inf)` (the identity has exactly the same branch cut).
- **Speed:** ~4x faster per call (0.13 ms vs 0.48 ms).
- **Dependency:** removes the need for MATLAB's Symbolic Math Toolbox equivalent.

## 2. `computeIII` arity bug fixed (SP branch now runs)

**Where:** `computeIII.m` -> `lamb_large/elliptic.py` (`computeIII`).

The MATLAB file declares **five** inputs (`a, A, B, x0, x1`) but all callers pass
**four**, so MATLAB raises "Not enough input arguments" and the original `greensp`
(S-P head-wave) path cannot run at all. The result depends only on `a, A, B`, so the
Python signature is `computeIII(a, A, B, x0=None, x1=None)` — the trailing arguments
are accepted but unused, matching the declared (but never exercised) MATLAB interface.

This is the only *behavioural* change: the SP contribution is now actually computed.

## 3. Rayleigh pole pair selected semantically, not by index

**Where:** `greenp.m` / `greens.m` index `p(1:2)` / `p(5:6)` ->
`lamb_large/polytools.py` (`split_pair`).

The MATLAB code picks the Rayleigh pole pair out of `residue`'s output **by position**,
relying on MATLAB's undocumented pole ordering. The port instead identifies it
**semantically**: the poles of RP/RS come in `+/-` pairs, and the Rayleigh pair is the
unique pair whose squared pole is real (the poles are `+/- i*a3`, with `a3^2` the real
root of the Rayleigh cubic). The derived coefficients (`u5/u6`, `v5/v6`) are invariant
under which member is listed first, and the remaining four poles are summed
symmetrically, so results are identical in the valid regime (`k > 1.7636`) — but the
selection no longer depends on an undocumented ordering.

## 4. Rayleigh cubic root selected by property, not by index

**Where:** `UPfunction.m`, `USfunction.m`, etc. use `root(1)` / `root(3)` ->
`lamb_large/u_integrals.py` (`_rayleigh_root_real`).

MATLAB picks the needed real root of the Rayleigh cubic by its position in `roots`'s
output. The port selects the root with the smallest imaginary part instead (the Rayleigh
cubic has exactly one real root for `k > 1.7636`). Same value, no dependence on root
ordering. The same principle applies to the ordering of the eq. (57) root pair
(`_s_roots` in `v_integrals.py`).

## 5. Symbolic `ellipticF` replaced by `mpmath`

**Where:** `ellip1_matlab.m` -> `lamb_large/elliptic.py` (`ellip1_matlab`).

MATLAB's `ellipticF(phi, m)` (Symbolic Math Toolbox) is replaced by `mpmath.ellipf`,
and `ellipke` by `mpmath.ellipk` / `mpmath.ellipe`. This removes the Symbolic Toolbox
dependency and gives explicit control over working precision.

## 6. Complex-limit integrals made explicit

**Where:** MATLAB `integral(f, 0, z1)` with complex `z1` ->
`lamb_large/elliptic.py` (`ellip1`, `ellip3`) and `lamb_large/johnson.py`
(`_quad_complex_segment`).

MATLAB's `integral` with a complex upper limit integrates along the straight segment
from the lower to the upper limit. The port reproduces that semantics explicitly:

- the elliptic helpers use high-precision `mpmath` quadrature (`workdps(25)`) along the
  segment, and
- the Johnson integrals parametrize the segment `z(u) = z1*u` and apply
  `scipy.integrate.quad` to the real and imaginary parts.

No approximation is introduced; this only makes MATLAB's implicit contour rule explicit.

## 7. Everything else is unchanged

- All numerator polynomials (`MPij`, `NPij`, `MSij`, `NSij`), the U and V integral
  blocks, the P/S/SP assembly, the `1/(pi^2 mu r)` normalisation, all branch guards
  (e.g. `Tp > 1`, `sin(theta) > 1/k`, the `VS1_m` second block) and the `xi1 < xi2`
  reordering are transcribed literally.
- The Johnson (1974) reference (`johnson*.m`) is ported as-is; it shares nothing with
  the closed form except the geometry helper, which is why it serves as an independent
  cross-check (see `VALIDATION.md`).

---

### Summary table

| # | change | type | effect on results |
|---|--------|------|-------------------|
| 1 | `hypergeom` -> `atanh(sqrt(z))/sqrt(z)` | exact identity | none (< 1e-21), ~4x faster |
| 2 | `computeIII` arity fix | bug fix | SP branch now runs (was an error in MATLAB) |
| 3 | Rayleigh pair by real-square test | robustness | identical |
| 4 | Rayleigh cubic root by min-imag | robustness | identical |
| 5 | `ellipticF`/`ellipke` -> `mpmath` | dependency | identical |
| 6 | complex-limit `integral` -> explicit contour | clarification | identical |
