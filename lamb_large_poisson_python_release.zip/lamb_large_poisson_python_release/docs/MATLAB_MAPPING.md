# MATLAB → Python mapping

File-by-file correspondence between the original MATLAB package
`lamb_large_poisson_ratio` and this Python port. The transcription is literal: every
formula, branch, and guard was carried over. Where a MATLAB idiom has no direct Python
equivalent, the substitution is noted.

A consolidated list of everything that was **updated** relative to the MATLAB code
(elementary replacement of the hypergeometric function, the `computeIII` fix, index-free
pole/root selection, etc.) is in [`CHANGES.md`](CHANGES.md).

## Core Green's function

| MATLAB          | Python (`lamb_large/green.py`)          | notes                                   |
|-----------------|------------------------------------------|-----------------------------------------|
| `green.m`       | `green`                                  | `(greenp+greens+greensp)/(pi^2 mu r)`   |
| `greenp.m`      | `greenp`                                 | P part, eq. (28)                        |
| `greens.m`      | `greens`                                 | S part, eq. (60)                        |
| `greensp.m`     | `greensp`                                | SP part, eq. (70); see fix below        |

## Johnson reference

| MATLAB           | Python (`lamb_large/johnson.py`)        | notes                                   |
|------------------|------------------------------------------|-----------------------------------------|
| `johnson.m`      | `johnson`                                | complete reference, eq. (1)             |
| `johnsonp.m`     | `johnsonp`                               | P part                                  |
| `johnsons1.m`    | `johnsons1`                              | S part, integral 1                      |
| `johnsons2.m`    | `johnsons2`                              | S part, integral 2                      |
| `johnsonsp.m`    | `johnsonsp`                              | SP part                                 |

MATLAB's `integral` is reproduced with `scipy.integrate.quad` applied separately to the
real and imaginary parts. Complex integration limits are handled by integrating along the
straight segment (MATLAB's documented behaviour for complex bounds).

## Numerator polynomials

| MATLAB     | Python (`lamb_large/parts.py`) | notes                              |
|------------|--------------------------------|------------------------------------|
| `MPij.m`   | `MPij`                         | eqs. (12)–(19)                     |
| `NPij.m`   | `NPij`                         | eqs. (20)–(27)                     |
| `MSij.m`   | `MSij`                         | eqs. (41)–(48)                     |
| `NSij.m`   | `NSij`                         | eqs. (49)–(56)                     |
| —          | `geometry`                     | shared helper: `R, r, theta, phi`  |

MATLAB `conv` -> `numpy.convolve` (aliased in `polytools.conv`).

## U integrals

| MATLAB          | Python (`lamb_large/u_integrals.py`) | notes                          |
|-----------------|---------------------------------------|--------------------------------|
| `UPfunction.m`  | `UPfunction`                          | eqs. (29)–(31)                 |
| `UP1_m.m`       | `UP1_m`                               | eq. (29) per-pole term         |
| `USfunction.m`  | `USfunction`                          | S counterpart                  |
| `US1_m.m`       | `US1_m`                               | S per-pole term                |

The real Rayleigh root is selected by smallest imaginary part
(`_rayleigh_root_real`) instead of MATLAB's index (`root(1)` / `root(3)`).

## V integrals

| MATLAB          | Python (`lamb_large/v_integrals.py`) | notes                          |
|-----------------|---------------------------------------|--------------------------------|
| `VPfunction.m`  | `VPfunction`                          | eqs. (34)–(39)                 |
| `VP1_m.m`       | `VP1_m`                               | eq. (33)                       |
| `VSfunction.m`  | `VSfunction`                          | eqs. (61)–(67)                 |
| `VS1_m.m`       | `VS1_m`                               | eq. (61); note `xi1 < xi2`     |
| `VSPfunction.m` | `VSPfunction`                         | eqs. (72)–(77)                 |
| `VSP1_m.m`      | `VSP1_m`                              | eq. (71)                       |

The S-root pair of eq. (57) is ordered so `xi1` has the larger real part
(`_s_roots`); `VS1_m` then re-orders to `xi1 < xi2` internally, exactly as the MATLAB
code does.

## Elliptic / special functions

| MATLAB            | Python (`lamb_large/elliptic.py`) | notes                                        |
|-------------------|------------------------------------|----------------------------------------------|
| `ellip1.m`        | `ellip1`                           | contour integral 0 -> x0 (complex)           |
| `ellip3.m`        | `ellip3`                           | third kind, contour 0 -> x0                  |
| `ellip1_matlab.m` | `ellip1_matlab`                    | `ellipticF(asin(x0), tau^2)` via `mp.ellipf` |
| `F.m`             | `F`                                | hypergeom -> `atanh(sqrt(z))/sqrt(z)`         |
| `computeIII.m`    | `computeIII`                       | arity fix, see below                         |

MATLAB `ellipticF` (Symbolic Toolbox) -> `mpmath.ellipf`; `ellipke` -> `mpmath.ellipk` /
`mpmath.ellipe`; `hypergeom([1/2,1],3/2,z)` -> the elementary identity above.

## Polynomial utilities

| MATLAB          | Python (`lamb_large/polytools.py`) | notes                                   |
|-----------------|-------------------------------------|-----------------------------------------|
| `conv`          | `conv` (= `numpy.convolve`)         | polynomial convolution                  |
| `residue`       | `residue`                           | partial fractions; simple poles         |
| (indexing)      | `split_pair`                        | Rayleigh pole pair by real-square test  |

The MATLAB code picks the Rayleigh pair by position (`p(1:2)`, `p(5:6)`), relying on the
undocumented pole ordering of `residue`. The port selects it semantically
(`polytools.split_pair`): the unique `+/-` pair whose squared pole is real. Results are
identical in the valid regime.

## Sample driver

| MATLAB   | Python                    | notes                                   |
|----------|---------------------------|-----------------------------------------|
| `test.m` | `examples/test_green.py`  | prints table; saves csv + png           |

---

## The one behavioural fix

`computeIII.m` declares **five** inputs (`a, A, B, x0, x1`) but the callers pass
**four**. In MATLAB this raises "Not enough input arguments", so the original `greensp`
(S-P head-wave) path cannot run. The Python `computeIII(a, A, B, x0=None, x1=None)` makes
the trailing arguments optional — the result depends only on `a, A, B` — so the SP branch
executes. This is the only intentional deviation from the MATLAB behaviour; it is
documented here for traceability.
