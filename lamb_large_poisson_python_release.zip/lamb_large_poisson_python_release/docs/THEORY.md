# Theory

Lamb's problem asks for the displacement field in a homogeneous, isotropic, unbounded
elastic medium (a "full space") produced by a concentrated point force. Its solution is
the elastodynamic Green's tensor `G_ij(x, t)`: the displacement in direction `i` at
receiver `x` and time `t` due to an impulsive unit force in direction `j` at the origin.

This package evaluates that tensor in closed form for the **large-Poisson's-ratio**
regime (`nu > 0.2631`, `k = vp/vs > 1.7636`), following Hu & Jiang (2024), a
modification of Feng & Zhan (2018).

---

## 1. Governing equations

Navier's equation for the displacement `u` in a homogeneous elastic solid:

```
rho * u_tt = (lambda + mu) * grad(div u) + mu * lap(u) + f
```

with Lamé parameters `lambda, mu`, density `rho`, P-wave speed `vp = sqrt((lambda+2mu)/rho)`
and S-wave speed `vs = sqrt(mu/rho)`. The velocity ratio is

```
k = vp/vs = sqrt((lambda + 2 mu)/mu),      nu = (k^2 - 2) / (2 (k^2 - 1)).
```

The condition `nu > 0.2631` is equivalent to `k > 1.7636`.

## 2. Decomposition

The Green's tensor is split into three physical arrivals, each a Cagniard-de Hoop
contribution:

```
G_ij = (P_ij + S_ij + SP_ij) / (pi^2 * mu * r),     r = |x|.
```

- **P** (`greenp`, eq. 28): the compressional arrival, onset at `t = r/vp`.
- **S** (`greens`, eq. 60): the shear arrival, onset at `t = r/vs`.
- **SP** (`greensp`, eq. 70): a head wave that exists only when
  `sin(theta) > 1/k`, where `theta` is the polar angle of the receiver.

`green` sums the three and applies the `1/(pi^2 mu r)` normalisation (eq. 1).

## 3. Numerator polynomials M and N

Each part is a ratio of a numerator polynomial (in the Cagniard variable) over a
Rayleigh denominator polynomial:

- **P part:** denominator `RP` built from the P-wave Rayleigh polynomial;
  numerators `MPij` (eqs. 12–19) and `NPij` (eqs. 20–27).
- **S / SP parts:** denominator `RS`; numerators `MSij` (eqs. 41–48) and
  `NSij` (eqs. 49–56).

These polynomials depend on the receiver geometry through `theta`, `phi`, and the
dimensionless times `Tp = vp*t/r` and `Ts = vs*t/r`. They are assembled with polynomial
convolution (`polytools.conv` = `numpy.convolve`) in `parts.py`.

## 4. Partial fractions and the Rayleigh pole pair

`polytools.residue` performs the partial-fraction expansion of `M/RP` (or `N/RS`).
Because the leading terms cancel, the Rayleigh polynomial has degree 6 with poles that
come in `+/-` pairs. One of those pairs is the **Rayleigh pole pair** `+/- i*a3`, where
`a3 = sqrt(-xr)` and `xr` is the (unique) real root of the Rayleigh cubic.

`polytools.split_pair` isolates that pair **semantically** — it is the unique `+/-` pair
whose squared pole is real — instead of relying on MATLAB's undocumented pole ordering
(`p(1:2)` for P, `p(5:6)` for S). The residues of the pair give the `u5/u6` (P/S U-part)
and `v5/v6` (V-part) coefficients; the remaining four poles are summed symmetrically.

## 5. The integrals U, V

After partial fractions, each part is a linear combination of tabulated integrals:

- **U-type** (`u_integrals.py`): `UPfunction`, `USfunction` return the closed forms
  `U2..U6`; `UP1_m`, `US1_m` add the per-pole `U1` contribution.
- **V-type** (`v_integrals.py`): `VPfunction`, `VSfunction`, `VSPfunction` return
  `V2..V7` expressed through **elliptic integrals** (first and third kind, complete and
  incomplete, with complex argument); `VP1_m`, `VS1_m`, `VSP1_m` add the per-pole `V1`.

The elliptic integrals and one logarithmic antiderivative are implemented in
`elliptic.py`.

## 6. Elliptic and hypergeometric helpers

- `ellip1`, `ellip3` — incomplete elliptic integrals of the first and third kind along a
  straight contour `0 -> x0` in the complex plane (MATLAB's semantics for a complex
  upper limit), evaluated with high-precision `mpmath` quadrature.
- `ellip1_matlab` — `ellipticF(asin(x0), tau^2)` via `mpmath.ellipf`.
- `ellipke` — complete elliptic integrals `K(m), E(m)` via `mpmath`.
- `F` — an antiderivative built from `2F1(1/2,1;3/2;z)`. The original code calls the
  hypergeometric function; this port uses the exact elementary identity

  ```
  2F1(1/2, 1; 3/2; z) = atanh(sqrt(z)) / sqrt(z),
  ```

  which is dramatically faster and agrees to ~1e-21 (see `docs/VALIDATION.md`). A short
  power series is used for tiny `|z|` to avoid cancellation.
- `computeIII` — a logarithmic closed form. The MATLAB file declares 5 inputs but is
  called with 4; here the trailing arguments are optional (see `docs/MATLAB_MAPPING.md`).

## 7. The Johnson (1974) reference

`johnson.py` evaluates the same tensor by directly integrating the slowness-domain
representation (Johnson 1974). It is a completely independent code path — it shares
nothing with the closed form except the geometry helper — and is therefore the primary
cross-check. The P part of both methods agrees to near machine precision; see
`docs/VALIDATION.md`.

## 8. Validity and limitations

- Requires `k = vp/vs > 1.7636` (`nu > 0.2631`). Outside this regime the Rayleigh root
  selection and the head-wave geometry differ and the code is not applicable.
- The S arrival shows the logarithmic singularity characteristic of the type-II solution.
- Off-diagonal components are not symmetric (`G13 != G31`) in this formulation; that
  asymmetry is present in the original MATLAB code and is reproduced faithfully.
