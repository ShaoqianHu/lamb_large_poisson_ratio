# lamb_large

**Exact closed-form Green's functions for Lamb's problem at large Poisson's ratio.**

`lamb_large` computes the elastodynamic full-space Green's tensor for Lamb's problem
(the displacement at a receiver due to a point force in a homogeneous, isotropic,
unbounded elastic medium) using an exact closed-form (Cagniard-de Hoop) solution that is
valid for **large Poisson's ratio**:

```
nu > 0.2631        <=>        k = vp/vs > 1.7636
```

This is a faithful Python port of the MATLAB package `lamb_large_poisson_ratio`
(Hu & Jiang, submitted 2024), itself a modification of the closed-form solution of
Feng & Zhan (2018, *Geophysical Journal International*).

---

## Why this package exists

Lamb's problem has exact solutions, but their form depends on the Poisson's ratio (or,
equivalently, on the velocity ratio `k = vp/vs`). The classical closed form of
Feng & Zhan (2018) covers the common (small-`nu`) regime. Softer / more compressible
media have **large** Poisson's ratio (`nu > 0.2631`, `k > 1.7636`), where the root
structure of the Rayleigh polynomial changes and the earlier formulas do not apply.
Hu & Jiang derived the corresponding type-II closed form for exactly this regime, and
this package ports that implementation to Python.

---

## Features

- **Closed-form solution** (`green`): no numerical slowness integration for the
  P, S and SP head-wave contributions — only a small number of special functions.
- **Independent numerical reference** (`johnson`): the same Green's function evaluated
  with the quadrature integrals of Johnson (1974), useful as a cross-check.
- **All 9 tensor components** `G_ij` via a single `ori` selector.
- **High-precision special functions** via `mpmath` for the elliptic / logarithmic
  terms, returned as standard Python `complex` / `float`.
- Pure Python; only depends on `numpy`, `scipy`, `mpmath`.

---

## Installation

From the release folder:

```bash
pip install .
```

or, for development (editable) with the plotting and test extras:

```bash
pip install -e ".[plot,test]"
```

or simply install the dependencies and add the folder to `PYTHONPATH`:

```bash
pip install -r requirements.txt
```

**Requirements:** Python >= 3.9, `numpy>=1.24`, `scipy>=1.10`, `mpmath>=1.3`.
`matplotlib` is optional and only needed by the plotting examples.

---

## Quick start

```python
import numpy as np
from lamb_large import green

# receiver position (source is at the origin)
x = np.array([10.0, 0.0, 2.0])

# velocities: k = vp/vs must be > 1.7636
vp = 8.0
k  = 3.0
velocity = (vp, vp / k)          # (vp, vs)

# material
rho = 2.0
mu  = rho * (vp / k) ** 2        # shear modulus

# evaluate G_33 at time t = 5 s
u = green(x, 5.0, velocity, ori=33, mu=mu)
print(float(np.real(u)))
```

The bundled example reproduces the original MATLAB `test.m`:

```bash
python examples/test_green.py
```

It prints, for a series of time samples, both the closed-form result and the Johnson
reference, saves `results.csv`, and writes a comparison plot `test_green.png`.

---

## API overview

The public API consists of two families of functions. All take the same argument
convention:

```
f(x, t, velocity, ori, mu)     -> complex (or float) Green's-function value
f(x, t, velocity, ori)         -> part contribution (unnormalised)
```

| argument   | meaning                                                            |
|------------|--------------------------------------------------------------------|
| `x`        | receiver position `[x1, x2, x3]`; source is at the origin          |
| `t`        | time (s)                                                            |
| `velocity` | tuple `(vp, vs)`; requires `vp/vs > 1.7636`                        |
| `ori`      | tensor component selector (see below)                              |
| `mu`       | shear modulus                                                      |

### Closed-form solution

| function  | returns                                        |
|-----------|------------------------------------------------|
| `green`   | complete Green's function, eq. (1): `(greenp+greens+greensp)/(pi^2 mu r)` |
| `greenp`  | P contribution, eq. (28)                       |
| `greens`  | S contribution, eq. (60)                       |
| `greensp` | SP head-wave contribution, eq. (70); nonzero only when `sin(theta) > 1/k` |

### Johnson (1974) numerical reference

| function     | returns                                    |
|--------------|--------------------------------------------|
| `johnson`    | complete Green's function by quadrature    |
| `johnsonp`   | P part                                     |
| `johnsons1`  | S part, integral 1                         |
| `johnsons2`  | S part, integral 2                         |
| `johnsonsp`  | SP part                                    |

### Component selector `ori`

`ori` encodes the tensor component `G_ij` as the two-digit integer `10*i + j`:

| `ori` | component | `ori` | component | `ori` | component |
|-------|-----------|-------|-----------|-------|-----------|
| `11`  | G_11      | `12`  | G_12      | `13`  | G_13      |
| `21`  | G_21      | `22`  | G_22      | `23`  | G_23      |
| `31`  | G_31      | `32`  | G_32      | `33`  | G_33      |

`12` and `21` share the same formula in this formulation (they are aliased).

---

## Package layout

```
lamb_large/
  __init__.py     public API + version
  green.py        green, greenp, greens, greensp
  johnson.py      johnson, johnsonp, johnsons1, johnsons2, johnsonsp
  parts.py        M/N numerator polynomials + geometry helper
  u_integrals.py  U-type integrals (UPfunction, UP1_m, USfunction, US1_m)
  v_integrals.py  V-type integrals (VP/VS/VSP functions and *_1_m)
  elliptic.py     elliptic/hypergeometric helpers
  polytools.py    polynomial residue / partial-fraction utilities
docs/             theory, validation and porting notes
examples/         runnable example scripts
tests/            pytest suite
```

---

## Documentation

Detailed notes live in [`docs/`](docs/):

- [`docs/CHANGES.md`](docs/CHANGES.md) — **what is updated relative to the MATLAB code**
  (hypergeometric replaced by an elementary identity, `computeIII` arity fix, index-free
  pole/root selection, Symbolic-Toolbox independence), each with its effect on results.
- [`docs/THEORY.md`](docs/THEORY.md) — physical problem, governing equations, and how
  the closed form is assembled from the P/S/SP parts.
- [`docs/VALIDATION.md`](docs/VALIDATION.md) — how the port was validated, the expected
  level of agreement, and the known deviations (with evidence they are properties of the
  original formulation, not porting errors).
- [`docs/MATLAB_MAPPING.md`](docs/MATLAB_MAPPING.md) — file-by-file correspondence between
  the original MATLAB sources and this Python package, including the one behavioural fix.

---

## Testing

```bash
pip install pytest
pytest tests/ -v
```

The suite checks the core regression invariant (the closed-form P part must equal the
Johnson P part to near machine precision), the elliptic/hypergeometric identities, and
the partial-fraction reconstruction. See `docs/VALIDATION.md`.

---

## References

1. Xi Feng and Haiming Zhan, *Exact closed-form solutions for Lamb's problem*,
   Geophysical Journal International, 214(1), 444–457, 2018.
2. Shaoqian Hu and Xiaohuan Jiang, *A note on exact closed-form solution for Lamb's
   problem with an arbitrary Poisson's ratio*, submitted, 2024.
3. L. R. Johnson, *Green's functions for a spherical earth*, Geophysical Journal of the
   Royal Astronomical Society, 37, 373–384, 1974 (numerical reference).

## License

The upstream MATLAB package does not state a license; please respect its terms before
redistributing.
