"""Evaluate all nine tensor components G_ij at a single time.

Demonstrates the ``ori`` selector. Note that in this formulation the off-diagonal
components are not symmetric (G_13 != G_31, etc.); that asymmetry is a property of the
original MATLAB code and is reproduced faithfully (see docs/VALIDATION.md).

Run:
    python examples/components.py
"""

import numpy as np

from lamb_large import green


def main():
    x = np.array([10.0, 0.0, 2.0])
    vp, k = 8.0, 3.0
    velocity = (vp, vp / k)
    rho = 2.0
    mu = rho * (vp / k) ** 2
    t = 5.0

    print(f"Green's tensor G_ij at t = {t} s, x = {x.tolist()}, k = {k}\n")
    header = "      " + "".join(f"{'j=' + str(j):>20}" for j in (1, 2, 3))
    print(header)
    for i in (1, 2, 3):
        row = f"i={i}   "
        for j in (1, 2, 3):
            val = float(np.real(green(x, t, velocity, 10 * i + j, mu)))
            row += f"{val:20.8e}"
        print(row)


if __name__ == "__main__":
    main()
