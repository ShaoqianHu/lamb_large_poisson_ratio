"""Closed-form vs Johnson reference for Lamb's problem (port of MATLAB test.m).

Evaluates both implementations of the Green's function over a time window and
prints a comparison table, then writes ``results.csv`` and ``test_green.png``.

Setup (matches the original test.m):
    receiver   x = [10, 0, 2]
    vp = 8,  k = vp/vs = 3   (=> vs = 8/3, k > 1.7636 as required)
    component  ori = 33  (G_33)
    rho = 2  =>  mu = rho * vs^2

Run:
    python examples/test_green.py
"""

import os
import time

import numpy as np

from lamb_large import green, johnson


def main():
    # --- problem setup -----------------------------------------------------
    x = np.array([10.0, 0.0, 2.0])     # receiver position
    vp = 8.0
    k = 3.0                            # velocity ratio (must be > 1.7636)
    vs = vp / k
    velocity = (vp, vs)
    ori = 33                           # tensor component G_33
    rho = 2.0
    mu = rho * vs ** 2                 # shear modulus

    # --- time sampling -----------------------------------------------------
    dt = 0.2
    t = np.arange(dt, 6.0 + dt / 2, dt)
    nt = len(t)
    gfn = np.zeros(nt)                 # closed form
    gfn1 = np.zeros(nt)                # Johnson reference

    print(f"{'t':>6}  {'green (closed form)':>22}  {'johnson (1974)':>22}")
    tic = time.time()
    for it in range(nt):
        gfn[it] = float(np.real(green(x, t[it], velocity, ori, mu)))
        gfn1[it] = float(np.real(johnson(x, t[it], velocity, ori, mu)))
        print(f"{t[it]:6.2f}  {gfn[it]:22.12e}  {gfn1[it]:22.12e}")
    print(f"\nelapsed: {time.time() - tic:.1f} s")

    # --- save csv ----------------------------------------------------------
    outdir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(outdir, "..", "results.csv")
    np.savetxt(csv_path, np.column_stack([t, gfn, gfn1]),
               header="t,green,johnson", delimiter=",", comments="")
    print(f"wrote {os.path.normpath(csv_path)}")

    # --- agreement summary -------------------------------------------------
    nonzero = np.abs(gfn1) > 1e-12
    print(f"max |green-johnson| = {np.max(np.abs(gfn - gfn1)):.3e}")
    if np.any(nonzero):
        rel = np.abs(gfn[nonzero] - gfn1[nonzero]) / np.abs(gfn1[nonzero])
        print(f"max relative diff (where |johnson|>1e-12) = {np.max(rel):.3e}")

    # --- optional plot -----------------------------------------------------
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.figure(figsize=(6, 5))
        plt.plot(t, gfn, "-", label="green (closed form)")
        plt.plot(t, gfn1, "--", label="johnson (1974)")
        plt.xlabel("time (s)")
        plt.ylabel("Green function")
        plt.title(f"Lamb's problem, G_{ori // 10}{ori % 10}, k={k}")
        plt.legend()
        plt.tight_layout()
        png_path = os.path.join(outdir, "..", "test_green.png")
        plt.savefig(png_path, dpi=140)
        print(f"wrote {os.path.normpath(png_path)}")
    except ImportError:
        print("(matplotlib not installed; skipped plot)")


if __name__ == "__main__":
    main()
