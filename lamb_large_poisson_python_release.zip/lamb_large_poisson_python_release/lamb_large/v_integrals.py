"""V-type integrals (ports of VPfunction.m, VP1_m.m, VSfunction.m, VS1_m.m,
VSPfunction.m, VSP1_m.m)."""

import numpy as np

from .elliptic import F, computeIII, ellip1, ellip1_matlab, ellip3, ellipke
from .parts import geometry
from .u_integrals import _rayleigh_root_real


def _csqrt(z):
    return np.sqrt(complex(z))


def _s_roots(Ts, theta, k):
    """Roots of equation (57); ordered so xi1 has the larger real part
    (both roots are real in the valid regime, where this is the convention
    the MATLAB formulas assume)."""
    ct = np.cos(theta)
    root = np.roots(np.array([1.0, -(Ts ** 2 + ct ** 2 - k ** (-2)) / (Ts * ct), 1 - k ** (-2)], dtype=complex))
    if root[0].real >= root[1].real:
        return root[0], root[1]
    return root[1], root[0]


def VPfunction(x, t, velocity):
    """Equations (34)-(39). Returns (Vr, Vk) = ([V2, V3], [V7, V6, V5, V4])."""
    _, _, theta, _ = geometry(x)
    alpha = velocity[0]
    beta = velocity[1]
    k = alpha / beta
    Tp = alpha * t / np.linalg.norm(x)
    ct, st = np.cos(theta), np.sin(theta)

    if Tp > 1:
        root = np.roots([1.0, -(Tp ** 2 + ct ** 2 - k ** 2) / (Tp * ct), 1 - k ** 2])
        if root[0].real > 0:
            xi1, xi2 = root[0], root[1]
        else:
            xi2, xi1 = root[0], root[1]
        C1 = -xi1 / xi2
        C2 = (xi1 - Tp * ct) / (Tp * ct - xi2)
        tau = _csqrt(C2 / C1)
        K, E = ellipke(tau ** 2)
        M = 1 / _csqrt(xi1 * (Tp * ct - xi2))

        xr = _rayleigh_root_real([16 * (k ** 2 - 1),
                                  8 * (3 * k ** 4 - 8 * k ** 2 + 6),
                                  8 * (k ** 6 - 6 * k ** 4 + 10 * k ** 2 - 6),
                                  (k ** 2 - 2) ** 4])
        a3 = np.sqrt(-xr)
        p = 1 / 2 * (xi1 + xi2) * (a3 ** 2 + xi2 ** 2) - 2 * xi2 * (a3 ** 2 + xi1 * xi2)
        q = -((a3 ** 2 + xi1 * xi2) / (2 * a3) * (a3 ** 2 - xi2 ** 2) + xi2 * (xi1 - xi2) * a3)
        m1 = p + 1j * q
        n1 = 2 * (a3 ** 2 + xi1 * xi2) ** 2 - (a3 ** 2 + xi1 ** 2) * (a3 ** 2 + xi2 ** 2) \
            + 2j * a3 * (a3 ** 2 + xi1 * xi2) * (xi1 - xi2)
        z2 = m1 / n1 * ellip3(-C2 * (a3 ** 2 + xi2 ** 2) ** 2 / n1, tau, 1)
        V2 = M / (a3 ** 2 + xi2 ** 2) * (2 * (xi1 - xi2) * z2.real + K)
        V3 = M / (a3 ** 2 + xi2 ** 2) * (-2 * a3 * (xi1 - xi2) * z2.imag + xi2 * K)

        V4 = M * K
        V5 = M * ((xi1 - xi2) * ellip3(-C2, tau, 1) + xi2 * K)
        V6 = M * (Tp * ct * xi2 * K + xi1 * (Tp * ct - xi2) * (E - K)
                  + Tp * ct * (xi1 - xi2) * ellip3(-C2, tau, 1))
        V7 = M / 2 * xi2 * (3 * Tp ** 2 * ct ** 2 - Tp ** 2 + 2 - k ** 2 - ct ** 2 - Tp * ct * xi1) * K \
            + M / 2 * 3 * Tp * ct * xi1 * (Tp * ct - xi2) * (E - K) \
            + M / 2 * (xi1 - xi2) * (3 * Tp ** 2 * ct ** 2 - Tp ** 2 + 2 - k ** 2 - ct ** 2) \
            * ellip3(-(xi1 - Tp * ct) / (Tp * ct - xi2), tau, 1)
    else:
        V2 = V3 = V4 = V5 = V6 = V7 = 0.0
    return np.array([V2, V3], dtype=complex), np.array([V7, V6, V5, V4], dtype=complex)


def VP1_m(x, t, velocity, a, rr):
    """Equation (33). a: a pole of RP, rr: its residue."""
    _, _, theta, _ = geometry(x)
    alpha = velocity[0]
    k = velocity[0] / velocity[1]
    Tp = alpha * t / np.linalg.norm(x)
    ct, st = np.cos(theta), np.sin(theta)

    if Tp > 1:
        root = np.roots([1.0, -(Tp ** 2 + ct ** 2 - k ** 2) / (Tp * ct), 1 - k ** 2])
        if root[0].real > 0:
            xi1, xi2 = root[0], root[1]
        else:
            xi2, xi1 = root[0], root[1]

        coef = 1.0 / _csqrt(xi2 * (xi2 - Tp * ct))
        C1 = -(xi1 - Tp * ct) / (Tp * ct - xi2)
        C2 = _csqrt(-C1) * 1j
        Cp1 = _csqrt(-xi1 / xi2)
        Cp2 = _csqrt(-C1)
        C3 = -(xi1 - a) / (xi2 - a)

        coefII = 1.0 / (xi2 - a)
        coefIII = (xi1 - xi2) / (xi2 - a) ** 2
        coefIV = -(xi1 - xi2) / (xi2 - a) ** 2

        int1II = -1j / Cp2 * ellip1(Cp1 / Cp2, 1j * C1 / Cp1)
        int2II = 1j / Cp1 * ellip1(Cp2 / Cp1, 1)

        int1III = 0
        int2III = 0.5 * F(C3 ** 2, Cp1 ** 2, Cp2 ** 2, C2 ** 2, 2) \
            - 0.5 * F(C3 ** 2, Cp1 ** 2, Cp2 ** 2, C1 ** 2, 2)

        int1IV = -1j / C3 / Cp2 * ellip3(-Cp1 ** 2 / C3 ** 2, Cp1 / Cp2, 1j * C1 / Cp1)
        int2IV = -1j / C3 / Cp1 * ellip3(-Cp2 ** 2 / C3 ** 2, Cp2 / Cp1, 1)

        int_ = coefII * (int1II + int2II) \
            + coefIII * (int1III + int2III) \
            + coefIV * (int1IV + int2IV)

        # the pole contribution
        b = 0.5 * (Tp ** 2 - 1) * st ** 2 / (Tp * ct - xi2) ** 2 + 0.5
        c = 0.5 * (xi1 - xi2) / (Tp * ct - xi2)
        aa = (xi1 - a) / (xi2 - a)
        xr, yi = aa.real, aa.imag
        if xr < 0 and yi > 0 and ((xr - 1.0) / b + 1) ** 2 + yi ** 2 / c ** 2 < 1.0:
            z2 = 2 * np.pi * 1j / _csqrt((a ** 2 - xi1 * xi2) * (a ** 2 - 2 * a * Tp * ct + Tp ** 2 - st ** 2))
        else:
            z2 = 0
        return float(np.imag(rr * (int_ * coef - z2)))
    return 0.0


def VSfunction(x, t, velocity):
    """Equations (61)-(67). Returns (Vr, Vk) = ([V2, V3], [V7, V6, V5, V4])."""
    _, r, theta, _ = geometry(x)
    beta = velocity[1]
    k = velocity[0] / velocity[1]
    Ts = beta * t / r
    ct = np.cos(theta)

    xi1, xi2 = _s_roots(Ts, theta, k)

    if t < r / beta:
        V2 = V3 = V4 = V5 = V6 = V7 = 0.0
    else:
        xr = _rayleigh_root_real([-16 * (k ** (-2) - 1),
                                  8 * (4 * k ** (-2) - 3),
                                  8 * (1 - 2 * k ** (-2)),
                                  1.0])
        a3 = np.sqrt(-xr)

        C1 = _csqrt(xi1 / xi2)
        C2 = _csqrt((xi1 - Ts * ct) / (Ts * ct - xi2))
        tau = _csqrt(C2 ** 2 / (C1 ** 2 + C2 ** 2))
        K, E = ellipke(tau ** 2)
        M = 1 / _csqrt(Ts * ct * (xi1 - xi2))

        p = 1 / 2 * (xi1 + xi2) * (a3 ** 2 + xi2 ** 2) - 2 * xi2 * (a3 ** 2 + xi1 * xi2)
        q = -((a3 ** 2 + xi1 * xi2) / (2 * a3) * (a3 ** 2 - xi2 ** 2) + xi2 * (xi1 - xi2) * a3)
        m1 = p + 1j * q
        n1 = C2 ** 2 * (a3 ** 2 + xi2 ** 2) ** 2 + 2 * (a3 ** 2 + xi1 * xi2) ** 2 \
            - (a3 ** 2 + xi1 ** 2) * (a3 ** 2 + xi2 ** 2) \
            + 2j * a3 * (a3 ** 2 + xi1 * xi2) * (xi1 - xi2)
        z2 = m1 / n1 * ellip3(C2 ** 2 * (a3 ** 2 + xi2 ** 2) ** 2 / n1, tau, 1)

        V2 = M / (a3 ** 2 + xi2 ** 2) * (2 * (xi1 - xi2) * z2.real + K)
        V3 = M / (a3 ** 2 + xi2 ** 2) * (-2 * (xi1 - xi2) * a3 * z2.imag + xi2 * K)
        V4 = M * K
        V5 = M * (xi2 * K + (Ts * ct - xi2) * ellip3((xi1 - Ts * ct) / (xi1 - xi2), tau, 1))
        V6 = M * (Ts * ct * (xi1 - xi2) * E + (xi1 * xi2 - (xi1 - xi2) * Ts * ct) * K) \
            + M * (Ts * ct - xi2) * Ts * ct * ellip3((xi1 - Ts * ct) / (xi1 - xi2), tau, 1)
        V7 = M / 2 * xi2 * (3 * Ts ** 2 * ct ** 2 - Ts ** 2 + 2 - k ** (-2) - np.cos(theta) ** 2 - Ts * ct * xi1) * K \
            - M / 2 * 3 * Ts * ct * xi1 * (Ts * ct - xi2) * K \
            + M / 2 * 3 * Ts ** 2 * ct ** 2 * (xi1 - xi2) * E \
            + M / 2 * (Ts * ct - xi2) * (3 * Ts ** 2 * ct ** 2 - Ts ** 2 + 2 - k ** (-2) - np.cos(theta) ** 2) \
            * ellip3((xi1 - Ts * ct) / (xi1 - xi2), tau, 1)
    return np.array([V2, V3], dtype=complex), np.array([V7, V6, V5, V4], dtype=complex)


def VS1_m(x, t, velocity, a, rr):
    """Equation (61). a: a pole of RS, rr: its residue.

    Note (as in the MATLAB code): here xi1 < xi2, to ensure
    xi2*(xi2 - Ts*cos(theta)) > 0, hence the minus sign in "coef"."""
    _, r, theta, _ = geometry(x)
    beta = velocity[1]
    k = velocity[0] / velocity[1]
    Ts = beta * t / r
    ct, st = np.cos(theta), np.sin(theta)

    if Ts > 1:
        root = np.roots(np.array([1.0, -(Ts ** 2 + ct ** 2 - k ** (-2)) / (Ts * ct), 1 - k ** (-2)], dtype=complex))
        if root[0].real > root[1].real:
            xi1, xi2 = root[1], root[0]
        else:
            xi1, xi2 = root[0], root[1]

        coef = -1.0 / _csqrt(xi2 * (xi2 - Ts * ct))
        C1 = -(xi1 - Ts * ct) / (Ts * ct - xi2)
        C2 = _csqrt(-C1) * 1j
        Cs1 = _csqrt(-xi1 / xi2)
        Cs2 = _csqrt(-C1)

        C3 = -(xi1 - a) / (xi2 - a)

        coefII = 1.0 / (xi2 - a)
        coefIII = (xi1 - xi2) / (xi2 - a) ** 2
        coefIV = -(xi1 - xi2) / (xi2 - a) ** 2 * C3

        int1II = 1j / Cs2 * ellip1_matlab(Cs1 / Cs2, 1j * C1 / Cs1)
        int2II = 1j / Cs1 * ellip1_matlab(Cs2 / Cs1, 1)

        int1III = 0.5 * F(C3 ** 2, Cs1 ** 2, Cs2 ** 2, 0, 1) - 0.5 * F(C3 ** 2, Cs1 ** 2, Cs2 ** 2, C1 ** 2, 1)
        int2III = 0.5 * F(C3 ** 2, Cs1 ** 2, Cs2 ** 2, C2 ** 2, 2) - 0.5 * F(C3 ** 2, Cs1 ** 2, Cs2 ** 2, 0, 2)

        int1IV = -1j / C3 ** 2 / Cs2 * ellip3(-Cs1 ** 2 / C3 ** 2, Cs1 / Cs2, 1j * C1 / Cs1)
        int2IV = -1j / C3 ** 2 / Cs1 * ellip3(-Cs2 ** 2 / C3 ** 2, Cs2 / Cs1, 1)

        int_ = coefII * (int1II + int2II) \
            + coefIII * (int1III + int2III) \
            + coefIV * (int1IV + int2IV)

        # the pole contribution
        b = 0.5 * (Ts ** 2 - 1) * st ** 2 / (Ts * ct - xi2) ** 2 + 0.5
        c = 0.5 * (xi1 - xi2) / (Ts * ct - xi2)
        aa = (xi1 - a) / (xi2 - a)
        xr, yi = aa.real, aa.imag
        if xr < 0 and yi > 0 and ((xr - 1.0) / b + 1) ** 2 + yi ** 2 / c ** 2 < 1.0:
            z2 = 2 * np.pi * 1j / _csqrt((a ** 2 - 1 + 1 / k ** 2) * (a ** 2 - 2 * a * Ts * ct + Ts ** 2 - st ** 2))
        else:
            z2 = 0
        V1 = float(np.imag(rr * (int_ * coef + z2)))

        if Ts * ct < np.sqrt(1 - 1 / k ** 2):
            upper = np.sqrt(1 - 1 / k ** 2)
            lower = Ts * ct

            C1 = (lower - xi1) / (lower - xi2)
            C2 = (upper - xi1) / (upper - xi2)

            int1II = +1j / Cs1 * ellip1(Cs2 / Cs1, -1j * C2 / Cs2) \
                     - 1j / Cs1 * ellip1(Cs2 / Cs1, -1j * C1 / Cs2)
            int1III = 0.5 * F(C3 ** 2, Cs1 ** 2, Cs2 ** 2, C2 ** 2, 1) \
                - 0.5 * F(C3 ** 2, Cs1 ** 2, Cs2 ** 2, C1 ** 2, 1)
            int1IV = -1j / C3 ** 2 / Cs1 * ellip3(-Cs2 ** 2 / C3 ** 2, Cs2 / Cs1, -1j * C2 / Cs2) \
                     + 1j / C3 ** 2 / Cs1 * ellip3(-Cs2 ** 2 / C3 ** 2, Cs2 / Cs1, -1j * C1 / Cs2)

            int_ = coefII * int1II + coefIII * int1III + coefIV * int1IV

            V2 = -float(np.imag(int_ * coef * rr))
        else:
            V2 = 0.0
        return V1 + V2
    return 0.0


def VSPfunction(x, t, velocity):
    """Equations (72)-(77). Returns (Vr, Vk) = ([Vsp2, Vsp3], [Vsp7, Vsp6, Vsp5, Vsp4])."""
    _, r, theta, _ = geometry(x)
    alpha = velocity[0]
    beta = velocity[1]
    k = alpha / beta
    Ts = beta * t / r
    ct, st = np.cos(theta), np.sin(theta)

    xi1, xi2 = _s_roots(Ts, theta, k)

    if t > r / beta:
        Vsp2 = Vsp3 = Vsp4 = Vsp5 = Vsp6 = Vsp7 = 0.0
    elif t < r / alpha * st + r * np.sqrt(beta ** (-2) - alpha ** (-2)) * ct:
        Vsp2 = Vsp3 = Vsp4 = Vsp5 = Vsp6 = Vsp7 = 0.0
    else:
        C1 = _csqrt(xi1 / xi2)
        C2 = _csqrt((xi1 - Ts * ct) / (xi2 - Ts * ct))
        tau = _csqrt(1 - C1 ** 2 / C2 ** 2)
        K, E = ellipke(tau ** 2)
        M = 1 / _csqrt((xi1 - Ts * ct) * xi2)

        xr = _rayleigh_root_real([-16 * (k ** (-2) - 1),
                                  8 * (4 * k ** (-2) - 3),
                                  8 * (1 - 2 * k ** (-2)),
                                  1.0])
        a3 = np.sqrt(-xr)
        p1 = (xi1 - 1j * a3) / (xi2 - 1j * a3)
        gama1 = -Ts * ct * (xi2 - 1j * a3) ** 2 / ((st ** 2 + a3 ** 2 - Ts ** 2 + 2 * a3 * Ts * ct * 1j) * xi2)
        part1 = p1 / (st ** 2 + a3 ** 2 - Ts ** 2 + 2 * a3 * Ts * ct * 1j) * ellip3(gama1, tau, 1)
        A1 = abs(st ** 2 + a3 ** 2 - Ts ** 2 + 2 * a3 * Ts * ct * 1j)
        theta1 = np.angle(st ** 2 + a3 ** 2 - Ts ** 2 + 2 * a3 * Ts * ct * 1j)
        part2 = np.pi / (2 * np.sqrt(a3 ** 2 + 1 - k ** (-2)) * np.sqrt(A1))

        Vsp2 = M * ((Ts * ct - xi2) * part1.imag / a3 + K / (a3 ** 2 + xi2 ** 2)) \
            - part2 * np.sin(theta1 / 2) / a3
        Vsp3 = M * ((Ts * ct - xi2) * part1.real + xi2 * K / (a3 ** 2 + xi2 ** 2)) \
            + part2 * np.cos(theta1 / 2)
        Vsp4 = M * K
        Vsp5 = M * (xi2 * K + (Ts * ct - xi2) * ellip3(Ts * ct / xi2, tau, 1)) + np.pi / 2
        Vsp6 = M * (xi2 * Ts * ct * K + xi2 * (xi1 - Ts * ct) * E
                    + (Ts * ct - xi2) * Ts * ct * ellip3(Ts * ct / xi2, tau, 1)) + Ts * ct * np.pi / 2
        Vsp7 = M / 2 * xi2 * (3 * Ts ** 2 * ct ** 2 + 2 * xi1 * xi2 - (xi1 + xi2) * Ts * ct - xi1 * Ts * ct) * K \
            + M / 2 * 3 * Ts * ct * xi2 * (xi1 - Ts * ct) * E \
            + M / 2 * (Ts * ct - xi2) * (3 * Ts ** 2 * ct ** 2 + 2 * xi1 * xi2 - Ts * ct * (xi1 + xi2)) \
            * ellip3(Ts * ct / xi2, tau, 1) \
            + np.pi / 4 * (3 * Ts ** 2 * ct ** 2 - Ts ** 2 - ct ** 2 + 2 - k ** (-2))
    return np.array([Vsp2, Vsp3], dtype=complex), np.array([Vsp7, Vsp6, Vsp5, Vsp4], dtype=complex)


def VSP1_m(x, t, velocity, a, rr):
    """Equation (71). a: a pole of RS, rr: its residue."""
    _, r, theta, _ = geometry(x)
    alpha = velocity[0]
    beta = velocity[1]
    k = alpha / beta
    Ts = beta * t / r
    ct, st = np.cos(theta), np.sin(theta)
    tsp = r / alpha * st + r * np.sqrt(1 / beta ** 2 - 1 / alpha ** 2) * ct

    if Ts < 1 and t > tsp:
        lower = Ts * ct + np.sqrt(1 - Ts ** 2) * st
        upper = np.sqrt(1 - 1 / k ** 2)

        xi1, xi2 = _s_roots(Ts, theta, k)

        coef = 1.0 / _csqrt(xi2 * (xi2 - Ts * ct))

        C1 = (lower - xi1) / (lower - xi2)
        C2 = (upper - xi1) / (upper - xi2)

        Cs1 = _csqrt(-xi1 / xi2)
        Cs2 = _csqrt((xi1 - Ts * ct) / (Ts * ct - xi2))
        C3 = -(xi1 - a) / (xi2 - a)

        coefII = 1.0 / (xi2 - a)
        coefIII = (xi1 - xi2) / (xi2 - a) ** 2
        coefIV = -(xi1 - xi2) / (xi2 - a) ** 2

        int1II = +1j / Cs1 * ellip1(Cs2 / Cs1, 1j * C2 / Cs2) \
                 - 1j / Cs1 * ellip1(Cs2 / Cs1, 1j * C1 / Cs2)

        int1III = 0.5 * computeIII(C3 ** 2, Cs1 ** 2, Cs2 ** 2, C2 ** 2)

        int1IV = -1j / C3 / Cs1 * ellip3(-Cs2 ** 2 / C3 ** 2, Cs2 / Cs1, 1j * C2 / Cs2) \
                 + 1j / C3 / Cs1 * ellip3(-Cs2 ** 2 / C3 ** 2, Cs2 / Cs1, 1j * C1 / Cs2)

        int_ = coefII * int1II + coefIII * int1III + coefIV * int1IV

        return -float(np.imag(int_ * coef * rr))
    return 0.0
