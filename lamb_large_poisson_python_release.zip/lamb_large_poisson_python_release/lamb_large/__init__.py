"""lamb_large - exact closed-form Green's functions for Lamb's problem.

Implements the type-II closed-form solution for Lamb's problem (the
elastodynamic full-space Green's tensor) valid for large Poisson's ratio:

    nu > 0.2631   <=>   k = vp/vs > 1.7636

The implementation is a Python port of the MATLAB package
``lamb_large_poisson_ratio`` (Hu & Jiang, submitted 2024), itself a
modification of Feng & Zhan (2018, Geophysical Journal International).

Two independent evaluation paths are provided:

* ``green`` and friends - the closed-form (Cagniard-de Hoop) solution,
  decomposed into P, S and SP head-wave contributions.
* ``johnson`` and friends - numerical reference integrals after
  Johnson (1974), useful as an independent cross-check.

Quick start
-----------
>>> import numpy as np
>>> from lamb_large import green
>>> x = np.array([10.0, 0.0, 2.0])      # receiver position
>>> velocity = (8.0, 8.0 / 3.0)         # (vp, vs), k = 3 > 1.7636
>>> mu = 2.0 * (8.0 / 3.0) ** 2         # shear modulus (rho = 2)
>>> u33 = green(x, 5.0, velocity, 33, mu)

See the top-level README.md and the docs/ directory for details.
"""

from .green import green, greenp, greens, greensp
from .johnson import johnson, johnsonp, johnsons1, johnsons2, johnsonsp

__version__ = "1.0.0"

__all__ = [
    "green", "greenp", "greens", "greensp",
    "johnson", "johnsonp", "johnsons1", "johnsons2", "johnsonsp",
    "__version__",
]
