"""Elliptic-integral helpers (ports of ellip1.m, ellip1_matlab.m, ellip3.m,
F.m, computeIII.m, plus ellipke used from VP/VS/VSP functions).

MATLAB's ``integral`` with a complex upper limit integrates along the
straight line from the lower to the upper limit; the contour-integral
implementations below reproduce exactly that semantics.  All evaluations
are done with mpmath at elevated precision and returned as Python complex.
"""

import mpmath as mp

_DPS = 25


def ellip1(tau, x0):
    """Port of ellip1.m: int_0^x0 dx/(sqrt(1-x^2)*sqrt(1-tau^2*x^2)),
    along the straight segment 0 -> x0."""
    with mp.workdps(_DPS):
        tau = mp.mpc(tau)
        x0 = mp.mpc(x0)
        if abs(x0) == 0:
            return 0j
        f = lambda u: x0 / (mp.sqrt(1 - (x0 * u) ** 2) * mp.sqrt(1 - tau ** 2 * (x0 * u) ** 2))
        return complex(mp.quad(f, [0, 0.5, 1]))


def ellip1_matlab(tau, x0):
    """Port of ellip1_matlab.m: ellipticF(asin(x0), tau^2)."""
    with mp.workdps(_DPS):
        phi = mp.asin(mp.mpc(x0))
        return complex(mp.ellipf(phi, mp.mpc(tau) ** 2))


def ellip3(c, tau, x0):
    """Port of ellip3.m: int_0^x0 dx/((1-c*x^2)*sqrt(1-x^2)*sqrt(1-tau^2*x^2)),
    along the straight segment 0 -> x0."""
    with mp.workdps(_DPS):
        c = mp.mpc(c)
        tau = mp.mpc(tau)
        x0 = mp.mpc(x0)
        if abs(x0) == 0:
            return 0j
        f = lambda u: x0 / ((1 - c * (x0 * u) ** 2) * mp.sqrt(1 - (x0 * u) ** 2)
                            * mp.sqrt(1 - tau ** 2 * (x0 * u) ** 2))
        return complex(mp.quad(f, [0, 0.5, 1]))


def ellipke(m):
    """Complete elliptic integrals K(m), E(m) with parameter m (may be complex).
    Matches MATLAB's [K,E]=ellipke(m) with analytic continuation for m outside [0,1)."""
    with mp.workdps(_DPS):
        m = mp.mpc(m)
        return complex(mp.ellipk(m)), complex(mp.ellipe(m))


def _hyp2f1_12132(z):
    """2F1(1/2, 1; 3/2; z) = atanh(sqrt(z))/sqrt(z), principal branch.

    Same branch cut as mp.hyp2f1 (z in [1, inf)) but far faster.
    """
    if abs(z) < 1e-6:
        return 1 + z / 3 + z * z / 5 + z * z * z / 7
    return mp.atanh(mp.sqrt(z)) / mp.sqrt(z)


def F(a, A, B, x, index):
    """Port of F.m: elementary antiderivatives used by VP1_m/VS1_m.

    The original MATLAB code writes hypergeom([1/2,1],3/2,z); the identity
    2F1(1/2,1;3/2;z) = atanh(sqrt(z))/sqrt(z) avoids the hypergeometric call.
    """
    with mp.workdps(_DPS):
        a = mp.mpc(a)
        A = mp.mpc(A)
        B = mp.mpc(B)
        x = mp.mpc(x)
        if index == 1:
            if abs(A + x) < 1e-10:
                return 0j
            z = (a + B) * (A + x) / ((a + A) * (B + x))
            val = 2 * (A + x) * _hyp2f1_12132(z) / (-a - A) / mp.sqrt((B + x) * (A + x))
        else:
            if abs(B + x) < 1e-10:
                return 0j
            z = (a + A) * (B + x) / ((a + B) * (A + x))
            val = 2 * (B + x) * _hyp2f1_12132(z) / (-a - B) / mp.sqrt((A + x) * (B + x))
        return complex(val)


def computeIII(a, A, B, x0=None, x1=None):
    """Port of computeIII.m (file declares computeIII_4(a,A,B,x0,x1)).
    The result depends only on a, A, B; x0/x1 are accepted but unused."""
    with mp.workdps(_DPS):
        a = mp.mpc(a)
        A = mp.mpc(A)
        B = mp.mpc(B)
        temp = mp.sqrt(A - B) * mp.sqrt(a + B) / mp.sqrt(-A - a) / mp.sqrt(-A + B)
        temp1 = mp.log(-1j * temp) - mp.log(1j * temp)
        return complex(-1j * temp1 / mp.sqrt((-A - a) * (a + B)))
