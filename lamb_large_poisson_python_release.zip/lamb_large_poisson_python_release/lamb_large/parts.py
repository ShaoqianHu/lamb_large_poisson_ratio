"""Numerator polynomials M and N (ports of MPij.m, NPij.m, MSij.m, NSij.m).

Polynomials in the Cagniard variable B, coefficients in descending powers.
"""

import numpy as np

from .polytools import conv


def geometry(x):
    x1, x2, x3 = x
    R = float(np.hypot(x1, x2))
    r = float(np.hypot(R, x3))
    theta = float(np.arctan(R / x3)) if x3 != 0 else np.pi / 2
    phi = float(np.arctan(x2 / x1)) if x1 != 0 else np.pi / 2
    return R, r, theta, phi


def MPij(x, t, velocity, ori):
    """Equations (12)-(19)."""
    _, _, theta, phi = geometry(x)
    alpha = velocity[0]
    k = velocity[0] / velocity[1]
    Tp = alpha * t / np.linalg.norm(x)

    b0 = np.array([1.0, 0.0])
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** 2 - 1])
    b4 = np.array([2.0, 0.0, k ** 2 - 2])
    b5 = np.array([np.cos(theta), -Tp])
    b6 = np.array([np.cos(theta) ** 2, -2 * Tp * np.cos(theta), Tp ** 2])
    b7 = np.array([1.0, -2 * Tp * np.cos(theta), Tp ** 2 - np.sin(theta) ** 2])
    b8 = np.array([1.0, 0.0, 0.0, 0.0])
    I1 = 8 / np.sin(theta) ** 2 * conv(conv(b1, b2), conv(b3, b6))
    I2 = 8 / np.sin(theta) ** 2 * conv(conv(b1, b2), conv(b3, b7))
    if ori == 11:
        return I1 * np.cos(phi) ** 2 - I2 * np.sin(phi) ** 2
    if ori == 22:
        return I1 * np.sin(phi) ** 2 - I2 * np.cos(phi) ** 2
    if ori in (12, 21):
        return (I1 + I2) * np.sin(phi) * np.cos(phi)
    if ori == 13:
        return 8 * np.cos(phi) / np.sin(theta) * conv(conv(b2, b3), conv(b5, b8))
    if ori == 23:
        return 8 * np.sin(phi) / np.sin(theta) * conv(conv(b2, b3), conv(b5, b8))
    if ori == 31:
        return np.cos(phi) / np.sin(theta) * conv(conv(b0, b5), conv(conv(b4, b4), b4))
    if ori == 32:
        return np.sin(phi) / np.sin(theta) * conv(conv(b0, b5), conv(conv(b4, b4), b4))
    if ori == 33:
        return conv(conv(b1, b4), conv(b4, b4))
    raise ValueError(f"unknown orientation {ori}")


def NPij(x, t, velocity, ori):
    """Equations (20)-(27)."""
    _, _, theta, phi = geometry(x)
    alpha = velocity[0]
    k = velocity[0] / velocity[1]
    Tp = alpha * t / np.linalg.norm(x)

    b0 = np.array([1.0, 0.0])
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** 2 - 1])
    b4 = np.array([2.0, 0.0, k ** 2 - 2])
    b5 = np.array([np.cos(theta), -Tp])
    b6 = np.array([np.cos(theta) ** 2, -2 * Tp * np.cos(theta), Tp ** 2])
    b7 = np.array([1.0, -2 * Tp * np.cos(theta), Tp ** 2 - np.sin(theta) ** 2])
    b8 = np.array([1.0, 0.0, 0.0, 0.0])
    I3 = 2 / np.sin(theta) ** 2 * conv(b6, conv(conv(b0, b3), conv(b4, b4)))
    I4 = 2 / np.sin(theta) ** 2 * conv(b7, conv(conv(b0, b3), conv(b4, b4)))
    I5 = 2 / np.sin(theta) * conv(conv(b3, b4), conv(b1, b5))
    if ori == 11:
        return I3 * np.cos(phi) ** 2 - I4 * np.sin(phi) ** 2
    if ori == 22:
        return I3 * np.sin(phi) ** 2 - I4 * np.cos(phi) ** 2
    if ori in (12, 21):
        return (I3 + I4) * np.sin(phi) * np.cos(phi)
    if ori == 13:
        return np.cos(phi) * conv(I5, b4)
    if ori == 23:
        return np.sin(phi) * conv(I5, b4)
    if ori == 31:
        return 2 * np.cos(phi) * conv(I5, b2)
    if ori == 32:
        return 2 * np.sin(phi) * conv(I5, b2)
    if ori == 33:
        return 4 * conv(conv(b2, b8), conv(b3, b4))
    raise ValueError(f"unknown orientation {ori}")


def MSij(x, t, velocity, ori):
    """Equations (41)-(48)."""
    _, _, theta, phi = geometry(x)
    beta = velocity[1]
    k = velocity[0] / velocity[1]
    Ts = beta * t / np.linalg.norm(x)

    b0 = np.array([1.0, 0.0])
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** (-2) - 1])
    b4 = np.array([2.0, 0.0, -1.0])
    b5 = np.array([np.cos(theta), -Ts])
    b6 = np.array([np.cos(theta) ** 2, -2 * Ts * np.cos(theta), Ts ** 2])
    b7 = np.array([1.0, -2 * Ts * np.cos(theta), Ts ** 2 - np.sin(theta) ** 2])
    b8 = np.array([1.0, 0.0, 0.0, 0.0])
    RS = conv(conv(b4, b4), conv(b4, b4)) - 16 * conv(conv(b1, b2), conv(b2, b3))
    I1 = RS + 1 / np.sin(theta) ** 2 * conv(conv(b4, conv(b4, b4)) - 16 * conv(conv(b1, b2), b3), b6)
    I2 = RS - 1 / np.sin(theta) ** 2 * conv(conv(b4, conv(b4, b4)) - 16 * conv(conv(b1, b2), b3), b7)
    if ori == 11:
        return I1 * np.cos(phi) ** 2 + I2 * np.sin(phi) ** 2
    if ori == 22:
        return I1 * np.sin(phi) ** 2 + I2 * np.cos(phi) ** 2
    if ori in (12, 21):
        return (I1 - I2) * np.sin(phi) * np.cos(phi)
    if ori == 13:
        return -np.cos(phi) / np.sin(theta) * conv(conv(b0, b5), conv(conv(b4, b4), b4))
    if ori == 23:
        return -np.sin(phi) / np.sin(theta) * conv(conv(b0, b5), conv(conv(b4, b4), b4))
    if ori == 31:
        return -8 * np.cos(phi) / np.sin(theta) * conv(conv(b2, b3), conv(b5, b8))
    if ori == 32:
        return -8 * np.sin(phi) / np.sin(theta) * conv(conv(b2, b3), conv(b5, b8))
    if ori == 33:
        return -8 * conv(conv(b1, b3), conv(b2, b2))
    raise ValueError(f"unknown orientation {ori}")


def NSij(x, t, velocity, ori):
    """Equations (49)-(56)."""
    _, _, theta, phi = geometry(x)
    beta = velocity[1]
    k = velocity[0] / velocity[1]
    Ts = beta * t / np.linalg.norm(x)

    b0 = np.array([1.0, 0.0])
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** (-2) - 1])
    b4 = np.array([2.0, 0.0, -1.0])
    b5 = np.array([np.cos(theta), -Ts])
    b6 = np.array([np.cos(theta) ** 2, -2 * Ts * np.cos(theta), Ts ** 2])
    b7 = np.array([1.0, -2 * Ts * np.cos(theta), Ts ** 2 - np.sin(theta) ** 2])
    b8 = np.array([1.0, 0.0, 0.0, 0.0])
    I3 = -4 / np.sin(theta) ** 2 * conv(conv(b3, b4), conv(b6, b8))
    I4 = 4 / np.sin(theta) ** 2 * conv(conv(b3, b4), conv(b7, b8))
    I5 = -2 / np.sin(theta) * conv(conv(b3, b4), conv(b1, b5))
    if ori == 11:
        return I3 * np.cos(phi) ** 2 + I4 * np.sin(phi) ** 2
    if ori == 22:
        return I3 * np.sin(phi) ** 2 + I4 * np.cos(phi) ** 2
    if ori in (12, 21):
        return (I3 - I4) * np.sin(phi) * np.cos(phi)
    if ori == 13:
        return 2 * np.cos(phi) * conv(I5, b2)
    if ori == 23:
        return 2 * np.sin(phi) * conv(I5, b2)
    if ori == 31:
        return np.cos(phi) * conv(I5, b4)
    if ori == 32:
        return np.sin(phi) * conv(I5, b4)
    if ori == 33:
        return -2 * conv(conv(conv(b2, b3), conv(b4, b4)), b0)
    raise ValueError(f"unknown orientation {ori}")
