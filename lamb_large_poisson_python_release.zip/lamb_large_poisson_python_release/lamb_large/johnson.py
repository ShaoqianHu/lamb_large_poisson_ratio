"""Johnson (1974) reference implementation (ports of johnson.m, johnsonp.m,
johnsons1.m, johnsons2.m, johnsonsp.m).

These evaluate the same Green's function by numerical integration and serve
as an independent check of the closed-form part.  MATLAB's ``integral`` is
reproduced with adaptive Gauss-Kronrod quadrature on the real and imaginary
parts; complex integration limits are handled by integrating along the
straight segment (MATLAB's documented behaviour for complex bounds).
"""

import numpy as np
from scipy.integrate import quad

from .parts import geometry


def _csqrt(z):
    return np.sqrt(complex(z))


def _quad_complex(f, a, b, points=None):
    kw = dict(limit=500, epsabs=1e-12, epsrel=1e-10)
    vr, _ = quad(lambda u: float(np.real(f(u))), a, b, points=points, **kw)
    vi, _ = quad(lambda u: float(np.imag(f(u))), a, b, points=points, **kw)
    return vr + 1j * vi


def _quad_complex_segment(f, z1):
    """int_0^z1 f(z) dz along the straight segment, = z1 * int_0^1 f(z1*u) du."""
    g = lambda u: z1 * f(z1 * u)
    return _quad_complex(g, 0.0, 1.0)


def _y_p(ori, phi, p, q, eta1, eta2, gama):
    cp, sp = np.cos(phi), np.sin(phi)
    if ori == 11:
        return 2 * eta2 * (q ** 2 * cp ** 2 - p ** 2 * sp ** 2)
    if ori in (12, 21):
        return 2 * eta2 * (q ** 2 + p ** 2) * cp * sp
    if ori == 22:
        return 2 * eta2 * (q ** 2 * sp ** 2 - p ** 2 * cp ** 2)
    if ori == 13:
        return 2 * q * eta1 * eta2 * cp
    if ori == 23:
        return 2 * q * eta1 * eta2 * sp
    if ori == 31:
        return q * gama * cp
    if ori == 32:
        return q * gama * sp
    if ori == 33:
        return eta1 * gama
    raise ValueError(f"unknown orientation {ori}")


def _y_s(ori, phi, p, q, eta1, eta2, gama):
    cp, sp = np.cos(phi), np.sin(phi)
    if ori == 11:
        return (gama * eta2 ** 2 - (q ** 2 * sp ** 2 - p ** 2 * cp ** 2) * (gama - 4 * eta1 * eta2)) / eta2
    if ori in (12, 21):
        return (q ** 2 + p ** 2) * (gama - 4 * eta1 * eta2) * sp * cp / eta2
    if ori == 22:
        return (gama * eta2 ** 2 - (q ** 2 * cp ** 2 - p ** 2 * sp ** 2) * (gama - 4 * eta1 * eta2)) / eta2
    if ori == 13:
        return -q * gama * cp
    if ori == 23:
        return -q * gama * sp
    if ori == 31:
        return -2 * q * eta1 * eta2 * cp
    if ori == 32:
        return -2 * q * eta1 * eta2 * sp
    if ori == 33:
        return 2 * eta1 * (q ** 2 - p ** 2)
    raise ValueError(f"unknown orientation {ori}")


def johnson(x, t, velocity, ori, mu):
    """The complete Green function by Johnson (1974), equation (1)."""
    r = np.linalg.norm(x)
    val = (johnsonp(x, t, velocity, ori) + johnsons1(x, t, velocity, ori)
           + johnsons2(x, t, velocity, ori) + johnsonsp(x, t, velocity, ori)) \
        / (np.pi ** 2 * mu * r)
    return np.real_if_close(val, tol=1000)


def johnsonp(x, t, velocity, ori):
    """The P part of the Green function by Johnson (1974), equation (2)."""
    _, r, theta, phi = geometry(x)
    alpha, beta = velocity[0], velocity[1]
    st, ct = np.sin(theta), np.cos(theta)

    if t < r / alpha:
        return 0.0
    p1 = float(np.sqrt(t ** 2 / r ** 2 - 1 / alpha ** 2))

    def p_(u):
        return p1 * np.sin(u)

    def q_(u):
        return -t / r * st + 1j * p1 * np.cos(u) * ct

    def eta1(u):
        return _csqrt(-q_(u) ** 2 + 1 / alpha ** 2 + p_(u) ** 2)

    def eta2(u):
        return _csqrt(-q_(u) ** 2 + 1 / beta ** 2 + p_(u) ** 2)

    def gama(u):
        return eta2(u) ** 2 + p_(u) ** 2 - q_(u) ** 2

    def sigma(u):
        return gama(u) ** 2 + 4 * eta1(u) * eta2(u) * (q_(u) ** 2 - p_(u) ** 2)

    def y1(u):
        return _y_p(ori, phi, p_(u), q_(u), eta1(u), eta2(u), gama(u)) * eta1(u) / sigma(u)

    return float(np.real(_quad_complex(y1, 0.0, np.pi / 2)))


def johnsons1(x, t, velocity, ori):
    """The S part of the Green function by Johnson (1974), equation (3) part 1."""
    _, r, theta, phi = geometry(x)
    alpha, beta = velocity[0], velocity[1]
    st, ct = np.sin(theta), np.cos(theta)

    if t < r / beta:
        return 0.0
    p1 = float(np.sqrt(t ** 2 / r ** 2 - 1 / beta ** 2))

    def p_(u):
        return p1 * np.sin(u)

    def q_(u):
        return -t / r * st + 1j * _csqrt(p1 ** 2 - p_(u) ** 2) * ct

    def eta1(u):
        return _csqrt(-q_(u) ** 2 + 1 / alpha ** 2 + p_(u) ** 2)

    def eta2(u):
        return t / r * ct + 1j * _csqrt(p1 ** 2 - p_(u) ** 2) * st

    def gama(u):
        return eta2(u) ** 2 + p_(u) ** 2 - q_(u) ** 2

    def sigma(u):
        return gama(u) ** 2 + 4 * eta1(u) * eta2(u) * (q_(u) ** 2 - p_(u) ** 2)

    def y1(u):
        return _y_s(ori, phi, p_(u), q_(u), eta1(u), eta2(u), gama(u)) * eta2(u) / sigma(u)

    return float(np.real(_quad_complex(y1, 0.0, np.pi / 2)))


def johnsons2(x, t, velocity, ori):
    """The S part of the Green function by Johnson (1974), equation (3) part 2."""
    _, r, theta, phi = geometry(x)
    alpha, beta = velocity[0], velocity[1]
    st, ct = np.sin(theta), np.cos(theta)

    if st < beta / alpha or t < r / beta:
        return 0.0
    p1 = float(np.sqrt(t ** 2 / r ** 2 - 1 / beta ** 2))
    p2 = _csqrt((t / r - np.sqrt(1 / beta ** 2 - 1 / alpha ** 2) * ct) ** 2 / st ** 2 - 1 / alpha ** 2)

    def p_(u):
        return p1 / np.cos(u)

    def q_(u):
        return -t / r * st + _csqrt(-p1 ** 2 + p_(u) ** 2) * ct

    def eta1(u):
        return _csqrt(-q_(u) ** 2 + 1 / alpha ** 2 + p_(u) ** 2)

    def eta2(u):
        return t / r * ct + _csqrt(-p1 ** 2 + p_(u) ** 2) * st

    def gama(u):
        return eta2(u) ** 2 + p_(u) ** 2 - q_(u) ** 2

    def sigma(u):
        return gama(u) ** 2 + 4 * eta1(u) * eta2(u) * (q_(u) ** 2 - p_(u) ** 2)

    def y1(u):
        return _y_s(ori, phi, p_(u), q_(u), eta1(u), eta2(u), gama(u)) * eta2(u) / (sigma(u) * np.cos(u))

    z1 = np.arccos(complex(p1 / p2))
    return float(-np.imag(_quad_complex_segment(y1, z1)))


def johnsonsp(x, t, velocity, ori):
    """The SP part of the Green function by Johnson (1974), equation (4)."""
    _, r, theta, phi = geometry(x)
    alpha, beta = velocity[0], velocity[1]
    st, ct = np.sin(theta), np.cos(theta)

    t1 = r / alpha * st + np.sqrt(1 / beta ** 2 - 1 / alpha ** 2) * r * ct
    if st < beta / alpha or t > r / beta or t < t1:
        return 0.0
    p1 = _csqrt(t ** 2 / r ** 2 - 1 / beta ** 2)
    p2 = _csqrt((t / r - np.sqrt(1 / beta ** 2 - 1 / alpha ** 2) * ct) ** 2 / st ** 2 - 1 / alpha ** 2)

    def p_(u):
        return u

    def q_(u):
        return -t / r * st + _csqrt(-p1 ** 2 + p_(u) ** 2) * ct

    def eta1(u):
        return _csqrt(-q_(u) ** 2 + 1 / alpha ** 2 + p_(u) ** 2)

    def eta2(u):
        return t / r * ct + _csqrt(-p1 ** 2 + p_(u) ** 2) * st

    def gama(u):
        return eta2(u) ** 2 + p_(u) ** 2 - q_(u) ** 2

    def sigma(u):
        return gama(u) ** 2 + 4 * eta1(u) * eta2(u) * (q_(u) ** 2 - p_(u) ** 2)

    def y1(u):
        return _y_s(ori, phi, p_(u), q_(u), eta1(u), eta2(u), gama(u)) * eta2(u) \
            / (sigma(u) * _csqrt(p_(u) ** 2 - p1 ** 2))

    if abs(p2.imag) < 1e-14 and p2.real > 0:
        return float(-np.imag(_quad_complex(y1, 0.0, p2.real)))
    return float(-np.imag(_quad_complex_segment(y1, p2)))
