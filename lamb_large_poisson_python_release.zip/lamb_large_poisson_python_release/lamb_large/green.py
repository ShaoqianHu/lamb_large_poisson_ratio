"""Closed-form Green's function (ports of green.m, greenp.m, greens.m, greensp.m)."""

import numpy as np

from .parts import MPij, MSij, NPij, NSij, geometry
from .polytools import conv, residue, split_pair
from .u_integrals import UP1_m, UPfunction, US1_m, USfunction
from .v_integrals import VP1_m, VPfunction, VS1_m, VSfunction, VSP1_m, VSPfunction


def _dot(kterm, vec):
    """MATLAB dot(k, vec): k may be shorter when leading coefficients cancel."""
    kterm = np.asarray(kterm, dtype=complex)
    if kterm.size < len(vec):
        kterm = np.concatenate([np.zeros(len(vec) - kterm.size, dtype=complex), kterm])
    return np.dot(kterm[:len(vec)], np.asarray(vec, dtype=complex))


def green(x, t, velocity, ori, mu):
    """The complete Green function, equation (1)."""
    r = np.linalg.norm(x)
    val = (greenp(x, t, velocity, ori) + greens(x, t, velocity, ori) + greensp(x, t, velocity, ori)) \
        / (np.pi ** 2 * mu * r)
    return np.real_if_close(val, tol=1000)


def greenp(x, t, velocity, ori):
    """P part of the Green function, equation (28)."""
    k = velocity[0] / velocity[1]
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** 2 - 1])
    b4 = np.array([2.0, 0.0, k ** 2 - 2])
    RP = conv(conv(b4, b4), conv(b4, b4)) - 16 * conv(conv(b1, b2), conv(b2, b3))

    M = MPij(x, t, velocity, ori)
    r1, p1, k1 = residue(M, RP)
    pp1, rr1, prest1, rrest1 = split_pair(p1, r1)
    u5 = -2 * pp1[0].imag * rr1[0].imag
    u6 = 2 * rr1[0].real
    Ur, Uk = UPfunction(x, t, velocity)
    nonellip = sum(UP1_m(x, t, velocity, prest1[j], rrest1[j]) for j in range(len(prest1))) \
        + _dot(k1, Uk) + u5 * Ur[0] + u6 * Ur[1]

    N = NPij(x, t, velocity, ori)
    r2, p2, k2 = residue(N, RP)
    pp2, rr2, prest2, rrest2 = split_pair(p2, r2)
    v5 = -2 * pp2[0].imag * rr2[0].imag
    v6 = 2 * rr2[0].real
    Vr, Vk = VPfunction(x, t, velocity)
    ellip = sum(VP1_m(x, t, velocity, prest2[j], rrest2[j]) for j in range(len(prest2))) \
        + _dot(k2, Vk) + v5 * Vr[0] + v6 * Vr[1]
    return nonellip + ellip


def greens(x, t, velocity, ori):
    """S part of the Green function, equation (60)."""
    k = velocity[0] / velocity[1]
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** (-2) - 1])
    b4 = np.array([2.0, 0.0, -1.0])
    RS = conv(conv(b4, b4), conv(b4, b4)) - 16 * conv(conv(b1, b2), conv(b2, b3))

    M = MSij(x, t, velocity, ori)
    r1, p1, k1 = residue(M, RS)
    pp1, rr1, prest1, rrest1 = split_pair(p1, r1)
    u5 = -2 * pp1[0].imag * rr1[0].imag
    u6 = 2 * rr1[0].real
    Ur, Uk = USfunction(x, t, velocity)
    nonellips = sum(US1_m(x, t, velocity, prest1[j], rrest1[j]) for j in range(len(prest1))) \
        + u5 * Ur[0] + u6 * Ur[1] + _dot(k1, Uk)

    N = NSij(x, t, velocity, ori)
    r2, p2, k2 = residue(N, RS)
    pp2, rr2, prest2, rrest2 = split_pair(p2, r2)
    v5 = -2 * pp2[0].imag * rr2[0].imag
    v6 = 2 * rr2[0].real
    Vr, Vk = VSfunction(x, t, velocity)
    ellips = sum(VS1_m(x, t, velocity, prest2[j], rrest2[j]) for j in range(len(prest2))) \
        + v5 * Vr[0] + v6 * Vr[1] + _dot(k2, Vk)
    return nonellips + ellips


def greensp(x, t, velocity, ori):
    """S-P part of the Green function, equation (70)."""
    _, _, theta, _ = geometry(x)
    k = velocity[0] / velocity[1]
    b1 = np.array([1.0, 0.0, 0.0])
    b2 = np.array([1.0, 0.0, -1.0])
    b3 = np.array([1.0, 0.0, k ** (-2) - 1])
    b4 = np.array([2.0, 0.0, -1.0])

    if np.sin(theta) > 1 / k:
        N = NSij(x, t, velocity, ori)
        RS = conv(conv(b4, b4), conv(b4, b4)) - 16 * conv(conv(b1, b2), conv(b2, b3))
        r2, p2, k2 = residue(N, RS)
        pp2, rr2, prest2, rrest2 = split_pair(p2, r2)
        v5 = -2 * pp2[0].imag * rr2[0].imag
        v6 = 2 * rr2[0].real
        Vr, Vk = VSPfunction(x, t, velocity)
        ellips = sum(VSP1_m(x, t, velocity, prest2[j], rrest2[j]) for j in range(len(prest2))) \
            + v5 * Vr[0] + v6 * Vr[1] + _dot(k2, Vk)
        return ellips
    return 0.0
