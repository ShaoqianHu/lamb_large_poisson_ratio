"""Polynomial tools replacing MATLAB's conv/residue.

The MATLAB code relies on the (undocumented) pole ordering of ``residue``
to pick out the Rayleigh pole pair by index (p1(1:2) in greenp, p1(5:6) in
greens).  Instead of reproducing that fragile ordering, ``split_pair``
selects the same pair semantically: the poles of RP/RS come in +/- pairs,
and the Rayleigh pair is the one whose square is real (it equals the real
root of the Rayleigh cubic, i.e. the poles are +/- i*a3).  All quantities
derived from the pair (u5/u6/v5/v6) are independent of which member is
listed first, and the remaining four poles are summed symmetrically, so the
result is identical to the MATLAB code in its valid regime (k > 1.7636).
"""

import numpy as np

conv = np.convolve


def _strip_leading_zeros(a):
    a = np.asarray(a, dtype=float)
    nz = np.flatnonzero(a)
    return a[nz[0]:] if nz.size else np.array([0.0])


def residue(num, den):
    """Partial fraction expansion like MATLAB's [r,p,k]=residue(b,a).

    Assumes simple poles (which holds generically for RP/RS when k > 1.7636):
        num(s)/den(s) = sum_i r_i/(s - p_i) + k(s)
    Coefficients are in descending powers, as in MATLAB.
    """
    num = _strip_leading_zeros(num)
    den = _strip_leading_zeros(den)
    if len(num) >= len(den):
        k, rem = np.polydiv(num, den)
    else:
        k = np.array([], dtype=float)
        rem = num
    p = np.roots(den)
    dden = np.polyder(den)
    r = np.array([np.polyval(rem, pi) / np.polyval(dden, pi) for pi in p], dtype=complex)
    return r, p, k


def split_pair(p, r):
    """Split poles/residues into the Rayleigh pair and the remaining poles.

    Returns (pair_p, pair_r, rest_p, rest_r):
      pair_p[0] is the member with the larger imaginary part (the +i*a3 pole),
      rest_* hold the other four poles in arbitrary order (they are always
      summed over symmetrically by the callers).
    """
    p = np.asarray(p, dtype=complex)
    r = np.asarray(r, dtype=complex)
    n = len(p)
    used = np.zeros(n, dtype=bool)
    pairs = []
    for i in range(n):
        if used[i]:
            continue
        j = int(np.argmin(np.abs(p + p[i])))
        if j == i:
            raise ValueError("pole without a +/- partner; unexpected polynomial")
        used[i] = used[j] = True
        pairs.append((i, j))
    # the Rayleigh pair is the +/- pair whose square is real within rounding;
    # no other +/- pair {p, -p} has this property (a pair {s, -conj(s)} does not)
    candidates = [pr for pr in pairs
                  if abs((p[pr[0]] ** 2).imag) <= 1e-9 * abs(p[pr[0]] ** 2)]
    if len(candidates) != 1:
        raise ValueError("could not identify the Rayleigh pole pair")
    i, j = candidates[0]
    if p[i].imag < p[j].imag:
        i, j = j, i
    rest = [idx for idx in range(n) if idx != i and idx != j]
    return p[[i, j]], r[[i, j]], p[rest], r[rest]
