"""U-type integrals (ports of UPfunction.m, UP1_m.m, USfunction.m, US1_m.m)."""

import numpy as np

from .parts import geometry


def _rayleigh_root_real(coeffs):
    """The Rayleigh cubic has exactly one real root for k > 1.7636; select it.
    (MATLAB picked it by index: root(1) for the P cubic, root(3) for the S cubic.)"""
    root = np.roots(np.asarray(coeffs, dtype=float))
    return root[int(np.argmin(np.abs(root.imag)))].real


def UPfunction(x, t, velocity):
    """Equations (29)-(31). Returns (Ur, Uk) = ([Up2, Up3], [Up6, Up5, Up4])."""
    _, _, theta, _ = geometry(x)
    alpha = velocity[0]
    beta = velocity[1]
    k = alpha / beta
    Tp = alpha * t / np.linalg.norm(x)

    xr = _rayleigh_root_real([16 * (k ** 2 - 1),
                              8 * (3 * k ** 4 - 8 * k ** 2 + 6),
                              8 * (k ** 6 - 6 * k ** 4 + 10 * k ** 2 - 6),
                              (k ** 2 - 2) ** 4])
    a3 = np.sqrt(-xr)

    if Tp > 1:
        s = np.sqrt(Tp ** 2 - 1) * np.sin(theta)
        z1 = 1j * Tp * np.cos(theta) + s + a3
        z2 = 1j * Tp * np.cos(theta) - s + a3
        A1, A2 = abs(z1), abs(z2)
        al1, al2 = np.angle(z1), np.angle(z2)
        Up2 = np.pi * np.cos((al1 + al2) / 2) / (2 * np.sqrt(A1 * A2) * a3)
        Up3 = np.pi * np.sin((al1 + al2) / 2) / (2 * np.sqrt(A1 * A2))
        Up4 = np.pi / 2
        Up5 = np.pi / 2 * Tp * np.cos(theta)
        Up6 = np.pi / 2 * Tp ** 2 * np.cos(theta) ** 2 - np.pi / 4 * (Tp ** 2 - 1) * np.sin(theta) ** 2
    else:
        Up2 = Up3 = Up4 = Up5 = Up6 = 0.0
    return np.array([Up2, Up3]), np.array([Up6, Up5, Up4])


def UP1_m(x, t, velocity, a, rr):
    """Equation (29). a: a pole (not the actual Rayleigh root), rr: its residue."""
    _, _, theta, _ = geometry(x)
    alpha = velocity[0]
    Tp = alpha * t / np.linalg.norm(x)

    if Tp > 1:
        C = Tp * np.cos(theta) - a + 1j * np.sqrt(Tp ** 2 - 1) * np.sin(theta)
        D = -2j * np.sqrt(Tp ** 2 - 1) * np.sin(theta)
        Up1 = np.pi / 2 * (1 / C * np.sqrt(C / (C + D)))
        return float(np.real(Up1 * rr))
    return 0.0


def USfunction(x, t, velocity):
    """Same as UPfunction with Tp replaced by Ts. Returns (Ur, Uk)."""
    _, _, theta, _ = geometry(x)
    beta = velocity[1]
    k = velocity[0] / velocity[1]
    Ts = beta * t / np.linalg.norm(x)

    xr = _rayleigh_root_real([-16 * (k ** (-2) - 1),
                              8 * (4 * k ** (-2) - 3),
                              8 * (1 - 2 * k ** (-2)),
                              1.0])
    a3 = np.sqrt(-xr)

    if Ts > 1:
        s = np.sqrt(Ts ** 2 - 1) * np.sin(theta)
        z1 = 1j * Ts * np.cos(theta) + s + a3
        z2 = 1j * Ts * np.cos(theta) - s + a3
        A1, A2 = abs(z1), abs(z2)
        al1, al2 = np.angle(z1), np.angle(z2)
        Us2 = np.pi * np.cos((al1 + al2) / 2) / (2 * np.sqrt(A1 * A2) * a3)
        Us3 = np.pi * np.sin((al1 + al2) / 2) / (2 * np.sqrt(A1 * A2))
        Us4 = np.pi / 2
        Us5 = np.pi / 2 * Ts * np.cos(theta)
        Us6 = np.pi / 2 * Ts ** 2 * np.cos(theta) ** 2 - np.pi / 4 * (Ts ** 2 - 1) * np.sin(theta) ** 2
    else:
        Us2 = Us3 = Us4 = Us5 = Us6 = 0.0
    return np.array([Us2, Us3]), np.array([Us6, Us5, Us4])


def US1_m(x, t, velocity, a, rr):
    """Equation (29) for the S part."""
    _, _, theta, _ = geometry(x)
    beta = velocity[1]
    Ts = beta * t / np.linalg.norm(x)

    if Ts > 1:
        C = Ts * np.cos(theta) - a + 1j * np.sqrt(Ts ** 2 - 1) * np.sin(theta)
        D = -2j * np.sqrt(Ts ** 2 - 1) * np.sin(theta)
        Us1 = np.pi / 2 * (1 / C * np.sqrt(C / (C + D)))
        Us1 = Us1 * 1j
        return float(np.imag(rr * Us1))
    return 0.0
