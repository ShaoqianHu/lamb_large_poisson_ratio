"""Fast identity checks (numpy/mpmath only, no scipy).

These verify the mathematical building blocks independently of the full
Green's-function machinery.
"""

import mpmath as mp
import numpy as np

from lamb_large.elliptic import _hyp2f1_12132
from lamb_large.polytools import conv, residue, split_pair


def test_hypergeom_identity_real_axis():
    """atanh(sqrt(z))/sqrt(z) reproduces 2F1(1/2,1;3/2;z) on the real axis."""
    with mp.workdps(40):
        for z in [-50.0, -1.0, -0.25, 0.0, 1e-9, 0.25, 0.5, 0.9, 0.999999]:
            ref = mp.hyp2f1(mp.mpf("0.5"), 1, mp.mpf("1.5"), mp.mpf(z))
            with mp.workdps(25):
                got = _hyp2f1_12132(mp.mpf(z))
            assert abs(mp.mpc(got) - ref) < 1e-18 * max(1, abs(ref))


def test_hypergeom_identity_complex_and_cut():
    """Agreement for complex arguments and on both sides of the cut [1, inf)."""
    pts = [complex(re, im) for re in (-2, 0.5, 2, 3) for im in (-1.5, 0.0, 1.5)]
    pts += [1.25 + 1e-9j, 1.25 - 1e-9j, 5.0 + 1e-9j]
    with mp.workdps(40):
        for z in pts:
            ref = mp.hyp2f1(mp.mpf("0.5"), 1, mp.mpf("1.5"), mp.mpc(z))
            with mp.workdps(25):
                got = _hyp2f1_12132(mp.mpc(z))
            rel = abs((mp.mpc(got) - ref) / ref) if abs(ref) > 0 else abs(mp.mpc(got))
            assert rel < 1e-18


def test_residue_reconstruction():
    """The partial-fraction expansion reconstructs num/den exactly."""
    num = np.array([1.0, 2.0, 3.0])
    den = conv(conv([1.0, 0.0, 1.0], [1.0, 0.0, 4.0]), [1.0, 1.0])
    r, p, k = residue(num, den)
    assert k.size == 0  # strictly proper
    s = 0.7 + 0.3j
    recon = sum(ri / (s - pi) for ri, pi in zip(r, p))
    assert abs(recon - np.polyval(num, s) / np.polyval(den, s)) < 1e-12


def test_split_pair_finds_rayleigh_pair():
    """split_pair isolates a +/- pair whose squared pole is real."""
    # poles: a Rayleigh-like imaginary pair +/- i*a3 and two generic pairs
    a3 = 0.86
    p = np.array([1j * a3, -1j * a3, 1 + 0.5j, -1 - 0.5j, -0.3 + 0.2j, 0.3 - 0.2j])
    r = np.arange(6, dtype=complex) + 1
    pair_p, pair_r, rest_p, rest_r = split_pair(p, r)
    sq = pair_p[0] ** 2
    assert abs(sq.imag) <= 1e-9 * abs(sq)          # squared pole is real
    assert abs(pair_p[0] + pair_p[1]) < 1e-12      # they are +/- partners
    assert len(rest_p) == 4 and len(rest_r) == 4


def test_geometry_helper():
    from lamb_large.parts import geometry
    x = np.array([10.0, 0.0, 2.0])
    R, r, theta, phi = geometry(x)
    assert np.isclose(R, 10.0)
    assert np.isclose(r, np.sqrt(104))
    assert np.isclose(theta, np.arctan(10.0 / 2.0))
    assert np.isclose(phi, 0.0)
