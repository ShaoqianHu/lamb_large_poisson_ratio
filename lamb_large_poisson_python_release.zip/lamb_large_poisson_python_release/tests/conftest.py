"""Shared fixtures for the lamb_large test suite."""

import numpy as np
import pytest


@pytest.fixture
def setup():
    """The standard test configuration (matches MATLAB test.m)."""
    x = np.array([10.0, 0.0, 2.0])
    vp = 8.0
    k = 3.0                       # > 1.7636 as required
    vs = vp / k
    rho = 2.0
    mu = rho * vs ** 2
    return dict(x=x, velocity=(vp, vs), mu=mu, ori=33, k=k, r=np.linalg.norm(x))
