"""Regression tests: closed form vs the independent Johnson reference.

These import scipy (via lamb_large.johnson) and are slower; mark them ``slow``.
The central invariant is that the closed-form P part equals the Johnson P part to
near machine precision (see docs/VALIDATION.md).
"""

import numpy as np
import pytest

from lamb_large import green, greenp, johnson, johnsonp


@pytest.mark.slow
class TestPAgreement:
    def test_p_part_matches_johnson(self, setup):
        """greenp == johnsonp to ~1e-13 over the time range."""
        for t in [1.4, 1.8, 2.6, 4.0, 5.0]:
            gp = float(np.real(greenp(setup["x"], t, setup["velocity"], setup["ori"])))
            jp = float(np.real(johnsonp(setup["x"], t, setup["velocity"], setup["ori"])))
            assert abs(gp - jp) < 1e-12, f"t={t}: greenp={gp}, johnsonp={jp}"


@pytest.mark.slow
class TestPhysicalBehaviour:
    def test_prearrival_zero(self, setup):
        """Before the P arrival (t < r/vp) the response is exactly zero."""
        vp = setup["velocity"][0]
        t_p = setup["r"] / vp
        for t in [0.2 * t_p, 0.5 * t_p, 0.9 * t_p]:
            assert float(np.real(green(setup["x"], t, setup["velocity"],
                                       setup["ori"], setup["mu"]))) == 0.0

    def test_total_close_to_johnson_at_late_time(self, setup):
        """At late time the total closed form tracks Johnson to ~1%."""
        t = 5.0
        g = float(np.real(green(setup["x"], t, setup["velocity"],
                                setup["ori"], setup["mu"])))
        j = float(np.real(johnson(setup["x"], t, setup["velocity"],
                                  setup["ori"], setup["mu"])))
        assert abs(g - j) / abs(j) < 0.02
